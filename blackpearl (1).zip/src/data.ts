/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Product } from "./types";

// Dynamic absolute paths to the generated images
export const BRAND_ASSETS = {
  hero: "/src/assets/images/blackpearl_hero_1779898558468.png",
  suit: "/src/assets/images/blackpearl_suit_1779898580941.png",
  dress: "/src/assets/images/blackpearl_dress_1779898600865.png",
  trench: "/src/assets/images/blackpearl_trench_1779898621646.png",
};

export const PRODUCTS: Product[] = [
  {
    id: "bp-trench",
    name: "Sartorial Draped Trench",
    price: 54000,
    category: "outerwear",
    description: "A masterclass in shadow and silhouette. Designed with an oversized drop-shoulder fit, extra wide structured collar, and deep storm flaps. Cut from premium heavyweight wool-cashmere blend that holds its architectural structure.",
    image: BRAND_ASSETS.trench,
    details: [
      "75% Merino Wool, 20% Cashmere, 5% Polyamide",
      "Full viscose inner lining for exquisite drape",
      "Double-breasted storm flap button closure",
      "Integrated detachable waist sash",
      "Dry clean by designer specialist only"
    ],
    sizes: ["XS", "S", "M", "L", "XL"],
    hasFreeShipping: true,
    rating: 4.9,
    sku: "BP-TRNCH-09B",
    stockCount: 15,
    inStock: true
  },
  {
    id: "bp-suit",
    name: "Architectural Blazer Suit",
    price: 43500,
    category: "tailoring",
    description: "A sharp, modern formulation of the classic double-breasted blazer. Featuring strong, structured shoulders and contrasting satin lapel trims. This piece commands attention in high-contrast stark monochrome.",
    image: BRAND_ASSETS.suit,
    details: [
      "100% Virgin Worsted Wool",
      "Structured shoulder padding with sharp tailoring lines",
      "Satin peak lapels and discrete welt pockets",
      "Double back vents for ease of movement",
      "Made in Italy"
    ],
    sizes: ["S", "M", "L", "XL"],
    hasFreeShipping: false,
    rating: 4.8,
    sku: "BP-BLZR-88S",
    stockCount: 0,
    inStock: false
  },
  {
    id: "bp-dress",
    name: "Monochrome Fluid Silk Gown",
    price: 46500,
    category: "dresses",
    description: "A study in liquid-like fluid silk that dances with the body's movement. Features a delicate cowl neckline, an open-back design with fine trailing ties, and an asymmetrical raw hemline.",
    image: BRAND_ASSETS.dress,
    details: [
      "100% Pure Mulberry Silk Crepe",
      "Deep cowl neck draped collar styling",
      "Graceful open-back with adjustable cross-back ties",
      "Raw unfinished premium edges",
      "Delivered in custom dust proof protective sleeve"
    ],
    sizes: ["XS", "S", "M", "L"],
    hasFreeShipping: true,
    rating: 5.0,
    sku: "BP-DRSS-71F",
    stockCount: 8,
    inStock: true
  },
  {
    id: "bp-ribbed-knit",
    name: "Minima High-Collar Ribbed Knit",
    price: 27000,
    category: "essentials",
    description: "Constructed using premium combed organic cotton yarn with an intricate wide vertical rib texture. Features an elegant extra-high mock collar designed to frame the neck beautifully under outer garments.",
    image: "https://images.unsplash.com/photo-1618244972963-dbee1a7edc95?auto=format&fit=crop&q=80&w=800&sat=-100",
    details: [
      "95% Combed Organic Cotton, 5% Elastane blend",
      "Breathable, high-density ribbed texture",
      "High mock neck styled collar",
      "Elongated sleeves with thumbhole detail",
      "Responsibly manufactured under fair trade"
    ],
    sizes: ["XS", "S", "M", "L", "XL"],
    hasFreeShipping: true,
    rating: 4.7,
    sku: "BP-KNIT-45K",
    stockCount: 22,
    inStock: true
  },
  {
    id: "bp-pants",
    name: "Schatten Pleated Tailored Trousers",
    price: 29250,
    category: "tailoring",
    description: "High-waisted draped trousers emphasizing absolute verticality. Twin deep front pleats create room, falling into a elegant wide-leg silhouette that brushes the floor gracefully.",
    image: "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?auto=format&fit=crop&q=80&w=800&sat=-100",
    details: [
      "80% Worsted Viscose, 20% Polyester",
      "Deep twin front pleats on each leg",
      "Hidden button and hook-and-bar fly closure",
      "Adjustable internal waist-tabs for ideal fit",
      "Subtle crease lines on front and back"
    ],
    sizes: ["XS", "S", "M", "L", "XL"],
    hasFreeShipping: false,
    rating: 4.6,
    sku: "BP-TROU-11P",
    stockCount: 5,
    inStock: true
  },
  {
    id: "bp-boots",
    name: "Sartorial Matte Leather Combat Boots",
    price: 36000,
    category: "accessories",
    description: "Crafted in premium matte black calfskin leather, combining military utility with a sleek runway silhouette. Features waxed cotton laces, custom brushed-steel speed hooks, and a robust welted sole.",
    image: "https://images.unsplash.com/photo-1608256246200-53e635b5b65f?auto=format&fit=crop&q=80&w=800&sat=-100",
    details: [
      "100% Genuine Italian Full-Grain Calfskin Leather",
      "Robust Goodyear-welt construction",
      "Reinforced heavy-duty pull tabs",
      "Resilient vibram-inspired grip outsoles",
      "Water-resistant wax finish"
    ],
    sizes: ["36", "38", "40", "42", "44"],
    hasFreeShipping: true,
    rating: 4.9,
    sku: "BP-BOOT-03L",
    stockCount: 3,
    inStock: true
  },
  {
    id: "bp-sunglasses",
    name: "Eclipse Acetate Sunglasses",
    price: 18000,
    category: "accessories",
    description: "Stark rectangular shades crafted in heavy hand-polished biological acetate. Featuring ultra-dark mineral glass lenses that block 100% of UVA/UVB rays, offering functional secrecy and absolute protection.",
    image: "https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&q=80&w=800&sat=-100",
    details: [
      "100% Biodegradable Acetate frame",
      "Scratch-resistant mineral glass lens in Charcoal",
      "Hypoallergenic custom optical hardware and studs",
      "Discrete laser logo engraving on inner temple",
      "Includes premium hard case and microfiber lens wipe"
    ],
    sizes: ["ONE SIZE"],
    hasFreeShipping: false,
    rating: 4.5,
    sku: "BP-ECLP-55S",
    stockCount: 12,
    inStock: true
  },
  {
    id: "bp-cotton-tee",
    name: "Raw-Edge Heavy Cotton Tee",
    price: 12750,
    category: "essentials",
    description: "Our signature basic, reimagined. Cut with a relaxed boxy fit in high-density 260GSM combed organic cotton. Designed with subtle hand-finished raw hems at the sleeve cuffs and waistline for a gentle avant-garde look.",
    image: "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&q=80&w=800&sat=-100",
    details: [
      "100% Organic Combed High-Density Cotton (260GSM)",
      "Structured dropped shoulder silhouette",
      "Hand-finished raw cuffs and hemline detail",
      "Pre-shrunk for consistent structural shape",
      "Ethically milled and tailored in Tokyo"
    ],
    sizes: ["XS", "S", "M", "L", "XL"],
    hasFreeShipping: false,
    rating: 4.7,
    sku: "BP-TEE-92C",
    stockCount: 1,
    inStock: true
  }
];
