/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import { Check, Info, X } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import Header from "./components/Header";
import Hero from "./components/Hero";
import Gallery from "./components/Gallery";
import ProductDetail from "./components/ProductDetail";
import CartDrawer from "./components/CartDrawer";
import CheckoutModal from "./components/CheckoutModal";
import Newsletter from "./components/Newsletter";
import Footer from "./components/Footer";
import AdminPanel from "./components/AdminPanel";
import { Product, CartItem, Order } from "./types";
import { PRODUCTS } from "./data";

interface ToastAlert {
  id: string;
  msg: string;
  type: "success" | "info";
}

export default function App() {
  const [currentView, setView] = useState<"landing" | "shop" | "admin">("landing");
  const [products, setProducts] = useState<Product[]>(() => {
    const cachedProducts = localStorage.getItem("blackpearl-products-ref");
    if (cachedProducts) {
      try {
        return JSON.parse(cachedProducts);
      } catch (err) {
        console.error("Failed to restore product catalog entries", err);
      }
    }
    return PRODUCTS;
  });
  const [cart, setCart] = useState<CartItem[]>([]);
  const [activeProduct, setActiveProduct] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [toasts, setToasts] = useState<ToastAlert[]>([]);

  const saveProductsToStorage = (updatedProducts: Product[]) => {
    setProducts(updatedProducts);
    localStorage.setItem("blackpearl-products-ref", JSON.stringify(updatedProducts));
  };

  // 1. Synchronize Cart with LocalStorage on hook mounting
  useEffect(() => {
    const cachedCart = localStorage.getItem("blackpearl-cart-ref");
    if (cachedCart) {
      try {
        setCart(JSON.parse(cachedCart));
      } catch (err) {
        console.error("Failed to restore cart selections", err);
      }
    }
  }, []);

  // Save changes to LocalStorage
  const saveCartToStorage = (updatedCart: CartItem[]) => {
    setCart(updatedCart);
    localStorage.setItem("blackpearl-cart-ref", JSON.stringify(updatedCart));
  };

  // 2. Custom Elegant monochrome Toast triggers
  const triggerToast = (msg: string, type: "success" | "info" = "success") => {
    const newToast: ToastAlert = {
      id: Math.random().toString(36).substr(2, 9),
      msg,
      type,
    };
    setToasts((prev) => [...prev, newToast]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== newToast.id));
    }, 4000);
  };

  // 3. E-Commerce Cart Logic
  const handleAddToCart = (product: Product, size: string, quantity: number) => {
    const existingIdx = cart.findIndex(
      (item) => item.product.id === product.id && item.selectedSize === size
    );

    let updatedCart = [...cart];

    if (existingIdx > -1) {
      updatedCart[existingIdx].quantity += quantity;
    } else {
      updatedCart.push({
        product,
        selectedSize: size,
        quantity,
      });
    }

    saveCartToStorage(updatedCart);
    triggerToast(`✓ Added ${quantity}x ${product.name} (${size}) to shopping bag.`);
  };

  const handleUpdateQty = (product: Product, size: string, delta: number) => {
    let updatedCart = cart
      .map((item) => {
        if (item.product.id === product.id && item.selectedSize === size) {
          return { ...item, quantity: Math.max(1, item.quantity + delta) };
        }
        return item;
      })
      .filter((item) => item.quantity > 0);

    saveCartToStorage(updatedCart);
  };

  const handleRemoveCartItem = (product: Product, size: string) => {
    const updatedCart = cart.filter(
      (item) => !(item.product.id === product.id && item.selectedSize === size)
    );
    saveCartToStorage(updatedCart);
    triggerToast(`Removed ${product.name} (${size}) from shopping bag.`, "info");
  };

  const handleClearCart = () => {
    saveCartToStorage([]);
  };

  // Checkout complete handler
  const handleOrderComplete = (order: Order) => {
    triggerToast(`✓ Secure Checkout Successful! Invoice registered: ${order.id}`);
  };

  const totalCartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  // Scroll smoothly to Newsletter footer anchor
  const handleScrollToNewsletter = () => {
    const newsletterEl = document.getElementById("club-newsletter-section");
    if (newsletterEl) {
      newsletterEl.scrollIntoView({ behavior: "smooth" });
    } else {
      // Switch view and wait
      setView("landing");
      setTimeout(() => {
        document.getElementById("club-newsletter-section")?.scrollIntoView({ behavior: "smooth" });
      }, 100);
    }
  };

  return (
    <div className="relative min-h-screen bg-white text-zinc-950 font-sans flex flex-col justify-between">
      {/* Premium Cinematic Grain Masking */}
      <div className="vintage-noise" />

      {/* Modern High-End Bar Navigation Header */}
      <Header
        currentView={currentView}
        setView={(v) => {
          setView(v);
          window.scrollTo({ top: 0, behavior: "smooth" });
        }}
        cartCount={totalCartCount}
        onCartOpen={() => setIsCartOpen(true)}
        onNewsletterClick={handleScrollToNewsletter}
      />

      {/* Main Screen Views Switch Stage */}
      <main className="flex-grow">
        <AnimatePresence mode="wait">
          {currentView === "landing" ? (
            <motion.div
              key="view-landing"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.6 }}
            >
              {/* Immersive Brand Cover */}
              <Hero onExploreClick={() => {
                setView("shop");
                window.scrollTo({ top: 0, behavior: "smooth" });
              }} />
            </motion.div>
          ) : currentView === "shop" ? (
            <motion.div
              key="view-shop"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.6 }}
            >
              {/* Product Gallery Grid */}
              <Gallery
                products={products}
                onProductClick={(product) => setActiveProduct(product)}
                onQuickAdd={(prod, size) => handleAddToCart(prod, size, 1)}
              />
            </motion.div>
          ) : (
            <motion.div
              key="view-admin"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.6 }}
            >
              {/* Product Management Admin Dashboard */}
              <AdminPanel
                products={products}
                onAddProduct={(newP) => saveProductsToStorage([newP, ...products])}
                onUpdateProduct={(updP) => saveProductsToStorage(products.map(p => p.id === updP.id ? updP : p))}
                onDeleteProduct={(id) => saveProductsToStorage(products.filter(p => p.id !== id))}
                onResetToDefaults={() => {
                  saveProductsToStorage(PRODUCTS);
                  triggerToast("↺ Catalog restored to default garments successfully.", "info");
                }}
              />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Unified, sleek subscription core on both pages */}
        <Newsletter />
      </main>

      {/* Minimal Footer brandings */}
      <Footer
        onNewsletterClick={handleScrollToNewsletter}
        onShopClick={() => {
          setView("shop");
          window.scrollTo({ top: 0, behavior: "smooth" });
        }}
      />

      {/* FLOATING SIDEBAR DRAWER OVERLAYS & MODALS */}

      {/* 1. Curated Garment Details Drawer Modal */}
      <ProductDetail
        product={activeProduct}
        onClose={() => setActiveProduct(null)}
        onAddToCart={(prod, size, qty) => {
          handleAddToCart(prod, size, qty);
          setActiveProduct(null);
        }}
      />

      {/* 2. Slide-out Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cart}
        onUpdateQty={handleUpdateQty}
        onRemoveItem={handleRemoveCartItem}
        onCheckoutOpen={() => {
          setIsCartOpen(false);
          setIsCheckoutOpen(true);
        }}
        onViewProductsClick={() => setView("shop")}
      />

      {/* 3. Secure multi-step visual checkout wizard */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        cartItems={cart}
        onClearCart={handleClearCart}
        onOrderComplete={handleOrderComplete}
      />

      {/* STAR STYLED MINIMAL MONOCHROME TOAST PORTAL */}
      <div className="fixed bottom-6 left-6 z-50 flex flex-col space-y-3 max-w-sm pointer-events-none select-none">
        <AnimatePresence>
          {toasts.map((t) => (
            <motion.div
              id={`toast-alert-${t.id}`}
              key={t.id}
              initial={{ opacity: 0, y: 15, x: -10 }}
              animate={{ opacity: 1, y: 0, x: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: -5 }}
              transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
              className="pointer-events-auto bg-zinc-950 text-white min-w-[280px] px-5 py-3.5 border border-zinc-800 shadow-2xl flex items-center justify-between space-x-4 font-mono text-[10px] uppercase tracking-widest"
            >
              <div className="flex items-center space-x-2.5">
                {t.type === "success" ? (
                  <Check size={11} className="text-zinc-50 shrink-0" />
                ) : (
                  <Info size={11} className="text-zinc-400 shrink-0" />
                )}
                <span>{t.msg}</span>
              </div>
              <button
                id={`toast-close-${t.id}`}
                onClick={() => setToasts((prev) => prev.filter((item) => item.id !== t.id))}
                className="text-zinc-500 hover:text-white transition-colors shrink-0 pl-1"
                title="Dismiss overlay feedback"
              >
                <X size={12} />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
