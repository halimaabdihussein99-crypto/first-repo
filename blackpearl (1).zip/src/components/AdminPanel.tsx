/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from "react";
import { Upload, Trash2, Edit, Plus, Check, X, CornerDownRight, Image as ImageIcon, RotateCcw } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Product, formatPrice } from "../types";

interface AdminPanelProps {
  products: Product[];
  onAddProduct: (product: Product) => void;
  onUpdateProduct: (product: Product) => void;
  onDeleteProduct: (id: string) => void;
  onResetToDefaults: () => void;
}

export default function AdminPanel({
  products,
  onAddProduct,
  onUpdateProduct,
  onDeleteProduct,
  onResetToDefaults
}: AdminPanelProps) {
  // Security credential locks for blackpearl registry entries
  const [passwordInput, setPasswordInput] = useState("");
  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    return sessionStorage.getItem("blackpearl-admin-session") === "authorized";
  });
  const [authError, setAuthError] = useState("");

  const handleAuthSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordInput === "blackpearl158308") {
      setIsAuthenticated(true);
      sessionStorage.setItem("blackpearl-admin-session", "authorized");
      setAuthError("");
    } else {
      setAuthError("Sartorial credential validation failed. Incorrect password.");
    }
  };

  // Form State
  const [editingId, setEditingId] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [price, setPrice] = useState<number | "">("");
  const [category, setCategory] = useState<Product["category"]>("essentials");
  const [description, setDescription] = useState("");
  const [image, setImage] = useState("");
  const [sku, setSku] = useState("");
  const [detailsText, setDetailsText] = useState(""); // Comma separated or new-lines
  const [selectedSizes, setSelectedSizes] = useState<string[]>(["S", "M", "L"]);
  const [hasFreeShipping, setHasFreeShipping] = useState(false);
  const [rating, setRating] = useState(5.0);
  const [stockCount, setStockCount] = useState<number>(10);
  const [inStock, setInStock] = useState<boolean>(true);

  // Drag and Drop Image states
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uiError, setUiError] = useState("");
  const [uiSuccess, setUiSuccess] = useState("");

  const categoriesOpts: { id: Product["category"]; label: string }[] = [
    { id: "outerwear", label: "Outerwear" },
    { id: "tailoring", label: "Tailoring" },
    { id: "dresses", label: "Dresses" },
    { id: "essentials", label: "Essentials" },
    { id: "accessories", label: "Accessories" },
  ];

  const sizeOptions = ["XS", "S", "M", "L", "XL", "36", "38", "40", "42", "44", "ONE SIZE"];

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const processFile = (file: File) => {
    if (!file.type.startsWith("image/")) {
      setUiError("Invalid file type. Please upload an image file.");
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      if (e.target?.result && typeof e.target.result === "string") {
        setImage(e.target.result);
        setUiSuccess("Photo processed and ready for preview!");
        setTimeout(() => setUiSuccess(""), 3000);
      }
    };
    reader.onerror = () => {
      setUiError("Failed to read image file.");
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processFile(e.target.files[0]);
    }
  };

  const triggerFileSelect = () => {
    fileInputRef.current?.click();
  };

  const handleSizeToggle = (size: string) => {
    if (selectedSizes.includes(size)) {
      setSelectedSizes(selectedSizes.filter((s) => s !== size));
    } else {
      setSelectedSizes([...selectedSizes, size]);
    }
  };

  const handleEditClick = (product: Product) => {
    setEditingId(product.id);
    setName(product.name);
    setPrice(product.price);
    setCategory(product.category);
    setDescription(product.description);
    setImage(product.image);
    setSku(product.sku);
    setDetailsText(product.details.join("\n"));
    setSelectedSizes(product.sizes);
    setHasFreeShipping(product.hasFreeShipping);
    setRating(product.rating || 5.0);
    setStockCount(product.stockCount !== undefined ? product.stockCount : 10);
    setInStock(product.inStock !== undefined ? product.inStock : true);
    setUiError("");
    setUiSuccess(`Editing: ${product.name}`);
    window.scrollTo({ top: 320, behavior: "smooth" });
  };

  const handleCancelEdit = () => {
    resetForm();
    setEditingId(null);
    setUiSuccess("");
  };

  const resetForm = () => {
    setName("");
    setPrice("");
    setCategory("essentials");
    setDescription("");
    setImage("");
    setSku("");
    setDetailsText("");
    setSelectedSizes(["S", "M", "L"]);
    setHasFreeShipping(false);
    setRating(5.0);
    setStockCount(10);
    setInStock(true);
    setEditingId(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!name.trim()) {
      setUiError("Product name is required.");
      return;
    }
    if (price === "" || price <= 0) {
      setUiError("Please enter a valid price in Kenyan Shillings.");
      return;
    }
    if (!description.trim()) {
      setUiError("Product description is required.");
      return;
    }
    if (!image.trim()) {
      setUiError("Product photo asset is required. Please upload or paste a URL.");
      return;
    }
    if (!sku.trim()) {
      setUiError("A unique SKU is required.");
      return;
    }
    if (selectedSizes.length === 0) {
      setUiError("Please select at least one dress or shoe size.");
      return;
    }

    const details = detailsText
      .split("\n")
      .map((d) => d.trim())
      .filter((d) => d.length > 0);

    const generatedProduct: Product = {
      id: editingId || `bp-${Date.now()}`,
      name: name.trim(),
      price: Number(price),
      category,
      description: description.trim(),
      image,
      details: details.length > 0 ? details : ["100% Combed Heavy Material", "Premium Sartorial Fit"],
      sizes: selectedSizes,
      hasFreeShipping,
      rating: Number(rating) || 5.0,
      sku: sku.trim().toUpperCase(),
      stockCount: Number(stockCount),
      inStock: inStock && stockCount > 0, // Auto out of stock if stockCount is 0, otherwise honors override
    };

    if (editingId) {
      onUpdateProduct(generatedProduct);
      setUiSuccess(`Successfully updated ${name.trim()}`);
    } else {
      onAddProduct(generatedProduct);
      setUiSuccess(`Successfully added ${name.trim()} to catalogue.`);
    }

    resetForm();
    setEditingId(null);
    setUiError("");
    setTimeout(() => setUiSuccess(""), 4000);
  };

  if (!isAuthenticated) {
    return (
      <div className="max-w-md mx-auto px-4 py-24 text-center space-y-8 select-none">
        <div className="space-y-3">
          <span className="font-mono text-[9px] text-zinc-400 uppercase tracking-[0.3em] block">
            Sartorial Lockscreen Gatekeeper
          </span>
          <h2 className="font-serif italic text-3xl md:text-4xl tracking-tight text-zinc-950 font-normal animate-pulse">
            Restricted Entry
          </h2>
          <p className="text-zinc-500 font-sans font-light text-xs leading-relaxed max-w-sm mx-auto">
            Authorized personnel only. Enter the blackpearl credentials to unlock collection catalogues, drag-and-drop uploaded photos, and configure custom stock logs.
          </p>
        </div>

        <form id="blackpearl-auth-form" onSubmit={handleAuthSubmit} className="space-y-4 text-left">
          <div className="space-y-2">
            <label htmlFor="admin-passcode" className="font-mono text-[10px] uppercase tracking-[0.15em] text-zinc-400 font-bold block">
              Administrative Passcode
            </label>
            <input
              id="admin-passcode"
              type="password"
              placeholder="••••••••••••••"
              value={passwordInput}
              onChange={(e) => setPasswordInput(e.target.value)}
              className="w-full bg-white border border-zinc-950 px-4 py-3.5 font-mono text-zinc-900 rounded-none text-xs tracking-widest placeholder:text-zinc-300 focus:outline-none focus:ring-0"
              autoFocus
            />
          </div>

          <AnimatePresence mode="wait">
            {authError && (
              <motion.p
                id="auth-error-msg"
                initial={{ opacity: 0, y: -4 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -4 }}
                className="text-red-700 font-mono text-[9px] uppercase tracking-wider font-bold"
              >
                ✕ {authError}
              </motion.p>
            )}
          </AnimatePresence>

          <button
            id="unlock-portal-btn"
            type="submit"
            className="w-full bg-zinc-950 text-white hover:bg-white hover:text-zinc-950 border border-zinc-950 py-4 uppercase font-mono text-[10px] tracking-widest font-bold transition-all cursor-pointer rounded-none flex items-center justify-center"
          >
            Unlock Controls
          </button>
        </form>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-8 py-10 space-y-12">
      {/* Header section with brand aesthetics */}
      <div className="border-b border-zinc-950 pb-6 flex flex-col md:flex-row md:items-end md:justify-between gap-4 select-none text-left">
        <div>
          <span className="font-mono text-[9px] tracking-[0.25em] text-zinc-400 uppercase">Blackpearl Sartorial Labs</span>
          <h1 className="font-serif italic text-3xl md:text-5xl text-zinc-950 tracking-tight font-normal mt-1">Admin Studio</h1>
          <p className="text-zinc-500 font-sans font-light text-xs sm:text-sm mt-2 max-w-2xl leading-relaxed">
            Curate and govern the blackpearl online clothing lines. Upload fine garment photos, update pricing in Kenya Shillings (KSH), manage exact inventory, and toggle seasonal lookbook styles.
          </p>
        </div>
        <div>
          <button
            onClick={() => {
              if (window.confirm("Are you sure you want to reset all products back to default looks? All custom entries will be overridden.")) {
                onResetToDefaults();
                setUiSuccess("Reverted database storage to original curated lines.");
              }
            }}
            className="flex items-center space-x-2 text-[10px] uppercase font-mono tracking-widest border border-zinc-300 py-2.5 px-4 hover:border-zinc-950 bg-white hover:bg-zinc-50 transition-all rounded-none cursor-pointer"
          >
            <RotateCcw size={11} />
            <span>Restore Factory Defaults</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Form Column - submits changes */}
        <div className="lg:col-span-12 xl:col-span-5 border border-zinc-950 p-6 md:p-8 space-y-6 bg-zinc-50 text-left">
          <div className="border-b border-zinc-950 pb-3 flex justify-between items-center">
            <h2 className="font-serif italic text-lg md:text-2xl text-zinc-950">
              {editingId ? "Modify Custom Fit" : "Add Sartorial Piece"}
            </h2>
            {editingId && (
              <button
                onClick={handleCancelEdit}
                className="text-[9px] font-mono tracking-widest uppercase text-zinc-400 hover:text-red-600 transition-colors flex items-center"
              >
                <X size={10} className="mr-1" /> Cancel Edit
              </button>
            )}
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Display message feedback */}
            <AnimatePresence mode="wait">
              {uiError && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="bg-red-50 text-red-900 border border-red-900 p-3 text-[10px] font-mono uppercase tracking-wide"
                >
                  ⚠ {uiError}
                </motion.div>
              )}
              {uiSuccess && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="bg-zinc-950 text-zinc-50 border border-zinc-950 p-3 text-[10px] font-mono uppercase tracking-wide"
                >
                  ✓ {uiSuccess}
                </motion.div>
              )}
            </AnimatePresence>

            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2 space-y-1.5">
                <label className="font-mono text-[9px] uppercase tracking-widest text-zinc-400 block font-bold">Garment Title</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Asymmetrical Tailored Coat"
                  className="w-full bg-white text-zinc-950 px-3.5 py-2.5 border border-zinc-950 font-sans text-xs uppercase tracking-wide rounded-none focus:outline-hidden"
                />
              </div>

              <div className="space-y-1.5">
                <label className="font-mono text-[9px] uppercase tracking-widest text-zinc-400 block font-bold">Price in KSh</label>
                <input
                  type="number"
                  value={price}
                  onChange={(e) => setPrice(e.target.value === "" ? "" : Number(e.target.value))}
                  placeholder="e.g. 45000"
                  className="w-full bg-white text-zinc-950 px-3.5 py-2.5 border border-zinc-950 font-mono text-xs rounded-none focus:outline-hidden font-semibold"
                />
              </div>

              <div className="space-y-1.5">
                <label className="font-mono text-[9px] uppercase tracking-widest text-zinc-400 block font-bold">Category Line</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as Product["category"])}
                  className="w-full bg-white text-zinc-950 px-3 py-2.5 border border-zinc-950 font-mono text-xs rounded-none uppercase tracking-wider focus:outline-hidden"
                >
                  {categoriesOpts.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.label}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="font-mono text-[9px] uppercase tracking-widest text-zinc-400 block font-bold">Inventory SKU</label>
                <input
                  type="text"
                  value={sku}
                  onChange={(e) => setSku(e.target.value)}
                  placeholder="e.g. BP-COAT-12X"
                  className="w-full bg-white text-zinc-950 px-3.5 py-2.5 border border-zinc-950 font-mono text-xs uppercase tracking-widest rounded-none focus:outline-hidden"
                />
              </div>

              <div className="space-y-1.5">
                <label className="font-mono text-[9px] uppercase tracking-widest text-zinc-400 block font-bold">Star Rating (1-5)</label>
                <input
                  type="number"
                  step="0.1"
                  min="1"
                  max="5"
                  value={rating}
                  onChange={(e) => setRating(Number(e.target.value))}
                  className="w-full bg-white text-zinc-950 px-3.5 py-2.5 border border-zinc-950 font-mono text-xs rounded-none focus:outline-hidden"
                />
              </div>
            </div>

            {/* Inventory Realtime controls */}
            <div className="p-4 border border-zinc-300 bg-white grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="font-mono text-[9px] uppercase tracking-widest text-zinc-400 block font-bold">Stock Quantity</label>
                <input
                  type="number"
                  min="0"
                  value={stockCount}
                  onChange={(e) => {
                    const count = Number(e.target.value);
                    setStockCount(count);
                    if (count === 0) {
                      setInStock(false);
                    } else if (count > 0 && stockCount === 0) {
                      setInStock(true);
                    }
                  }}
                  className="w-full bg-white text-zinc-950 px-3 py-2 border border-zinc-950 font-mono text-xs rounded-none focus:outline-hidden font-bold"
                />
              </div>

              <div className="space-y-1.5 flex flex-col justify-end pb-1.5 select-none">
                <span className="font-mono text-[9px] uppercase tracking-widest text-zinc-400 block font-bold mb-1">Stock Availability</span>
                <label className="flex items-center space-x-2.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={inStock && stockCount > 0}
                    disabled={stockCount === 0}
                    onChange={(e) => setInStock(e.target.checked)}
                    className="w-4 h-4 accent-zinc-950"
                  />
                  <span className={`font-mono text-[10px] uppercase font-bold tracking-wider ${stockCount === 0 ? "text-zinc-300 line-through" : "text-zinc-955"}`}>
                    {stockCount === 0 ? "Out of stock" : (inStock ? "Currently In Stock" : "Force Out of Stock")}
                  </span>
                </label>
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="font-mono text-[9px] uppercase tracking-widest text-zinc-400 block font-bold">Philosophy and Description</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Write the lookbook copy details for this item..."
                rows={3}
                className="w-full bg-white text-zinc-950 p-3.5 border border-zinc-950 font-sans text-xs leading-relaxed rounded-none focus:outline-hidden"
              />
            </div>

            {/* HIGH END IMAGE UPLOADER Drag and Drop block */}
            <div className="space-y-2">
              <label className="font-mono text-[9px] uppercase tracking-widest text-zinc-400 block font-bold">Garment Portfolio Photo</label>

              {/* Box container */}
              <div
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                onClick={triggerFileSelect}
                className={`border-2 border-dashed p-5 text-center transition-all cursor-pointer flex flex-col items-center justify-center space-y-2 select-none ${
                  isDragging
                    ? "border-zinc-950 bg-zinc-200/50"
                    : image
                    ? "border-zinc-350 bg-white"
                    : "border-zinc-300 bg-white hover:border-zinc-950"
                }`}
              >
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  accept="image/*"
                  className="hidden"
                />
                
                {image ? (
                  <div className="relative w-full aspect-video max-h-[120px] bg-zinc-50 border border-zinc-950 overflow-hidden group">
                    <img src={image} alt="Preview upload" className="w-full h-full object-cover object-center" />
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                      <span className="text-white font-mono text-[9px] uppercase tracking-widest">Replace Photo</span>
                    </div>
                  </div>
                ) : (
                  <>
                    <Upload size={20} className="text-zinc-400" />
                    <div>
                      <p className="font-mono text-[10px] uppercase tracking-widest text-zinc-950 font-bold">Drag & Drop Garment Photo</p>
                      <p className="text-[9px] font-sans text-zinc-400 mt-0.5 uppercase">or click to browse filesystem</p>
                    </div>
                  </>
                )}
              </div>

              {/* Direct Paste Input URL option */}
              <div className="flex items-center space-x-2 bg-white border border-zinc-950 px-3 py-1.5 focus-within:border-zinc-950 transition-colors">
                <ImageIcon size={12} className="text-zinc-400 shrink-0" />
                <input
                  type="text"
                  value={image}
                  onChange={(e) => setImage(e.target.value)}
                  placeholder="Or paste high-end photo URL directly..."
                  className="w-full bg-white text-zinc-950 border-0 font-sans text-xs rounded-none focus:outline-inner focus:outline-hidden p-1 placeholder-zinc-300"
                />
              </div>
            </div>

            {/* Sizing Toggles */}
            <div className="space-y-1.5 pt-1">
              <label className="font-mono text-[9px] uppercase tracking-widest text-zinc-400 block font-bold">Aesthetic Size Availability</label>
              <div className="flex flex-wrap gap-1.5 select-none">
                {sizeOptions.map((s) => {
                  const active = selectedSizes.includes(s);
                  return (
                    <button
                      type="button"
                      key={s}
                      onClick={() => handleSizeToggle(s)}
                      className={`px-3 py-2 border text-[10px] font-mono tracking-widest uppercase transition-all rounded-none cursor-pointer ${
                        active
                          ? "bg-zinc-950 text-white border-zinc-950 font-bold"
                          : "bg-white text-zinc-400 border-zinc-300 hover:border-zinc-950 hover:text-zinc-95o"
                      }`}
                    >
                      {s}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Atelier Collection Check */}
            <label className="flex items-center space-x-2.5 cursor-pointer pt-1 select-none">
              <input
                type="checkbox"
                checked={hasFreeShipping}
                onChange={(e) => setHasFreeShipping(e.target.checked)}
                className="w-4 h-4 accent-zinc-950 text-zinc-950"
              />
              <span className="font-mono text-[10px] uppercase font-bold tracking-widest text-zinc-950">
                Atelier Signature Collection Piece
              </span>
            </label>

            {/* Fabric/Garment Care specifications details */}
            <div className="space-y-1.5 pt-1">
              <label className="font-mono text-[9px] uppercase tracking-widest text-zinc-400 block font-bold">Fabric Composition & Care (One per line)</label>
              <textarea
                value={detailsText}
                onChange={(e) => setDetailsText(e.target.value)}
                placeholder="e.g. 100% Genuine Kenyan combed wool&#10;Handmade tailored inner pockets&#10;Dry clean safe only"
                rows={3}
                className="w-full bg-white text-zinc-950 p-3 border border-zinc-950 font-mono text-xs leading-relaxed rounded-none focus:outline-hidden"
              />
            </div>

            <button
              id="submit-product-btn"
              type="submit"
              className="w-full bg-zinc-950 text-white hover:bg-white hover:text-zinc-950 border border-zinc-950 py-4 uppercase font-mono text-xs tracking-widest font-bold transition-all cursor-pointer rounded-none mt-4 flex items-center justify-center space-x-2"
            >
              <Plus size={13} />
              <span>{editingId ? "Save Sartorial Changes" : "Submit Garment to Catalogue"}</span>
            </button>
          </form>
        </div>

        {/* Inventory Portfolio Grid List Column */}
        <div className="lg:col-span-12 xl:col-span-7 space-y-6 text-left">
          <div className="border-b border-zinc-950 pb-3 flex justify-between items-baseline select-none">
            <h2 className="font-serif italic text-lg md:text-2xl text-zinc-950">Active Catalog Portfolio</h2>
            <span className="font-mono text-[10px] tracking-wider text-zinc-400 uppercase">{products.length} Designs registered</span>
          </div>

          <div className="border border-zinc-950 divide-y divide-zinc-950 bg-white">
            {products.map((p) => {
              const isItemInStock = p.stockCount !== undefined ? p.stockCount > 0 : (p.inStock !== false);
              const qtyLeft = p.stockCount !== undefined ? p.stockCount : 10;
              return (
                <div key={p.id} className="p-4 md:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-6 hover:bg-zinc-50 transition-colors">
                  <div className="flex items-start space-x-4">
                    {/* Tiny visual block image preview */}
                    <div className="w-14 h-[18.67px] aspect-[3/4] bg-neutral-100 border border-zinc-950 shrink-0 overflow-hidden relative select-none">
                      <img src={p.image} alt={p.name} className="w-full h-full object-cover object-center grayscale" />
                    </div>

                    <div className="space-y-1">
                      <span className="font-mono text-[8px] uppercase tracking-[0.2em] text-zinc-400 block">{p.category}</span>
                      <h3 className="font-serif italic text-base md:text-lg text-zinc-955 leading-tight">{p.name}</h3>
                      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 pt-1 font-mono text-[9px] uppercase tracking-wider text-zinc-500">
                        <span className="text-zinc-950 font-bold">{formatPrice(p.price)}</span>
                        <span>SKU: {p.sku}</span>
                        <span>Rating: {p.rating.toFixed(1)}/5.0</span>
                      </div>

                      {/* Stock detail line badge */}
                      <div className="pt-2 flex items-center space-x-2 select-none">
                        {isItemInStock ? (
                          <span className={`inline-flex items-center px-1.5 py-0.5 border text-[8px] font-mono font-bold tracking-widest uppercase ${
                            qtyLeft <= 3 ? "bg-amber-50 text-amber-900 border-amber-900" : "bg-emerald-50 text-emerald-900 border-emerald-900"
                          }`}>
                            {qtyLeft <= 3 ? `LOW STOCK • ${qtyLeft} UNIT${qtyLeft > 1 ? "S" : ""} LEFT` : `IN STOCK • ${qtyLeft} UNITS`}
                          </span>
                        ) : (
                          <span className="inline-flex items-center px-1.5 py-0.5 bg-zinc-950 text-white border border-zinc-950 text-[8px] font-mono tracking-widest uppercase font-bold">
                            OUT OF STOCK
                          </span>
                        )}

                        {p.hasFreeShipping && (
                          <span className="inline-flex items-center px-1.5 py-0.5 bg-white text-zinc-950 border border-zinc-950 text-[8px] font-mono tracking-widest uppercase">
                            FREE DISPATCH
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex sm:flex-col items-center sm:items-end justify-start gap-2.5 shrink-0">
                    <button
                      id={`edit-item-${p.id}`}
                      onClick={() => handleEditClick(p)}
                      className="flex-1 sm:flex-none flex items-center justify-center space-x-1 px-3.5 py-2 border border-zinc-950 text-zinc-950 hover:bg-zinc-950 hover:text-white font-mono text-[9px] uppercase tracking-widest transition-all rounded-none cursor-pointer"
                    >
                      <Edit size={10} />
                      <span>Edit</span>
                    </button>
                    <button
                      id={`delete-item-${p.id}`}
                      onClick={() => {
                        if (window.confirm(`Are you sure you want to delete "${p.name}"? This will permanently remove it from catalog registries.`)) {
                          onDeleteProduct(p.id);
                          setUiSuccess(`Removed "${p.name}" from catalog.`);
                        }
                      }}
                      className="flex-1 sm:flex-none flex items-center justify-center space-x-1 px-3.5 py-2 border border-red-950 text-red-900 hover:bg-red-900 hover:text-white font-mono text-[9px] uppercase tracking-widest transition-all rounded-none cursor-pointer"
                    >
                      <Trash2 size={10} />
                      <span>Delete</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="border border-zinc-950 p-4 font-mono text-[9px] uppercase tracking-wider text-zinc-650 bg-zinc-50 select-none">
            <p className="font-bold border-b border-zinc-300 pb-1.5 mb-2 text-zinc-950">Aesthetic Administration Note:</p>
            <p className="leading-relaxed">
              * Fabric specifications and sized units submitted above synchronize safely to standard LocalStorage. Custom images uploaded from your hard drive are converted to compressed base64 asset streams for instant sandboxed visual display.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
