/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Star, MapPin, Plus } from "lucide-react";
import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Product, formatPrice } from "../types";

interface ProductCardProps {
  key?: string;
  product: Product;
  onClick: () => void;
  onQuickAdd: (product: Product, size: string) => void;
}

export default function ProductCard({ product, onClick, onQuickAdd }: ProductCardProps) {
  const [hovered, setHovered] = useState(false);
  const [showQuickSizes, setShowQuickSizes] = useState(false);

  // Check if product is out of stock (using stockCount if present, or fallback to inStock flag)
  const isOutOfStock = product.stockCount !== undefined ? product.stockCount === 0 : (product.inStock === false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => {
        setHovered(false);
        setShowQuickSizes(false);
      }}
      className="group relative flex flex-col bg-white text-left select-none"
    >
      {/* Visual Thumbnail Frame */}
      <div className="relative aspect-[3/4] bg-neutral-100 overflow-hidden border border-zinc-950 flex items-center justify-center">
        {/* Main image with slightly muted opacity on out-of-stock items */}
        <img
          src={product.image}
          alt={product.name}
          className={`w-full h-full object-cover object-center grayscale hover:scale-102 duration-1000 transition-transform cursor-pointer ${
            isOutOfStock ? "opacity-45" : "opacity-100"
          }`}
          onClick={onClick}
          referrerPolicy="no-referrer"
        />

        {/* Atelier Signature Tag */}
        {product.hasFreeShipping && (
          <div className="absolute top-3 left-3 bg-white border border-zinc-950 text-zinc-950 px-2.5 py-1 flex items-center space-x-1.5 shadow-xs text-[9px] font-mono tracking-widest uppercase font-medium">
            <MapPin size={10} />
            <span>Atelier Piece</span>
          </div>
        )}

        {/* Out of stock Banner Badge */}
        {isOutOfStock ? (
          <div className="absolute top-3 right-3 bg-zinc-950 text-white border border-zinc-950 px-2.5 py-1 font-mono text-[9px] tracking-widest uppercase font-bold shadow-xs">
            Out Of Stock
          </div>
        ) : (
          product.stockCount !== undefined && product.stockCount <= 3 && (
            <div className="absolute top-3 right-3 bg-white text-zinc-950 border border-zinc-950 px-2.5 py-1 font-mono text-[9px] tracking-widest uppercase font-bold shadow-xs">
              Only {product.stockCount} Left
            </div>
          )
        )}

        {/* Rating overlay badge */}
        <div className="absolute bottom-3 left-3 bg-white text-zinc-950 border border-zinc-950 px-2 py-0.5 text-[9px] font-mono flex items-center space-x-1">
          <Star size={9} className="fill-zinc-950 text-zinc-950" />
          <span>{product.rating.toFixed(1)}</span>
        </div>

        {/* Quick Add overlay button (disabled when out of stock) */}
        {!isOutOfStock && (
          <div className="absolute bottom-3 right-3 z-10">
            <AnimatePresence mode="wait">
              {!showQuickSizes ? (
                <motion.button
                  id={`quick-add-btn-${product.id}`}
                  key="add-btn"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: hovered ? 1 : 0, scale: hovered ? 1 : 0.9 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowQuickSizes(true);
                  }}
                  className="bg-zinc-950 text-white hover:bg-white hover:text-zinc-950 border border-zinc-950 p-2.5 shadow-md flex items-center justify-center rounded-none transition-all cursor-pointer"
                  title="Quick Add size to bag"
                >
                  <Plus size={14} />
                </motion.button>
              ) : (
                <motion.div
                  key="sizes-panel"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="bg-white border border-zinc-950 text-zinc-950 rounded-none px-2 py-1.5 flex items-center space-x-1.5 shadow-md font-mono text-[9px]"
                  onClick={(e) => e.stopPropagation()}
                >
                  <span className="text-zinc-400 font-medium uppercase select-none mr-1">ADD:</span>
                  {product.sizes.map((size) => (
                    <button
                      id={`quick-size-${product.id}-${size}`}
                      key={size}
                      onClick={() => {
                        onQuickAdd(product, size);
                        setShowQuickSizes(false);
                      }}
                      className="w-5 h-5 flex items-center justify-center text-zinc-950 hover:bg-zinc-950 hover:text-white transition-all font-semibold rounded-none cursor-pointer"
                    >
                      {size}
                    </button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}
      </div>

      {/* Metadata Panel */}
      <div className="pt-4 pb-2 flex flex-col justify-between flex-grow">
        <div className="flex justify-between items-start">
          <div className="space-y-1">
            <span className="font-mono text-[9px] uppercase tracking-[0.2em] text-zinc-400">{product.category}</span>
            <h3
              onClick={onClick}
              className={`font-serif italic text-base text-zinc-955 hover:line-through transition-all cursor-pointer font-normal mt-0.5 block ${
                isOutOfStock ? "text-zinc-400 font-light" : "text-zinc-955"
              }`}
            >
              {product.name}
            </h3>
          </div>
          <span className={`font-mono text-sm font-semibold pl-2 ${isOutOfStock ? "text-zinc-400 line-through" : "text-zinc-950"}`}>
            {formatPrice(product.price)}
          </span>
        </div>

        <div className="mt-3 text-zinc-400 font-mono text-[9px] tracking-widest uppercase flex justify-between items-center selection:bg-none">
          <span>SKU: {product.sku}</span>
          {isOutOfStock && <span className="text-[8px] font-bold text-red-700 uppercase tracking-widest">OUT OF STOCK</span>}
        </div>
      </div>
    </motion.div>
  );
}
