/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { ArrowRight, Mail, Sparkles } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function Newsletter() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "subbing" | "success" | "error">("idle");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !/\S+@\S+\.\S+/.test(email)) {
      setStatus("error");
      setTimeout(() => setStatus("idle"), 3000);
      return;
    }

    setStatus("subbing");
    // Simulate premium registration process
    setTimeout(() => {
      setStatus("success");
    }, 1200);
  };

  return (
    <section id="club-newsletter-section" className="bg-neutral-50 border-t border-zinc-950 py-24 px-4 md:px-8 select-none">
      <div className="max-w-4xl mx-auto text-center space-y-8">
        <div className="space-y-3">
          <span className="font-mono text-[10px] text-zinc-400 uppercase tracking-[0.3em] block">Atelier Updates</span>
          <h2 className="font-serif italic text-3xl md:text-5xl tracking-tighter text-zinc-950 font-normal">
            Join the Atelier Mailing List
          </h2>
          <p className="text-zinc-550 font-sans font-light text-xs sm:text-sm max-w-lg mx-auto leading-relaxed">
            Subscribe to receive priority access to limited monochrome releases, Kyoto and Rome atelier dispatches, and lookbook previews.
          </p>
        </div>

        <AnimatePresence mode="wait">
          {status !== "success" ? (
            <motion.form
              key="newsletter-form"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onSubmit={handleSubmit}
              className="max-w-md mx-auto relative flex flex-col sm:flex-row items-center border-b border-zinc-950 pb-2 bg-transparent focus-within:border-zinc-900 transition-all text-left"
            >
              <div className="relative w-full flex items-center">
                <span className="absolute left-1 text-zinc-400">
                  <Mail size={13} />
                </span>
                <input
                  id="newsletter-email-input"
                  type="email"
                  placeholder="EMAIL ADDRESS"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-transparent border-0 py-3 pl-8 pr-4 font-mono text-[11px] tracking-widest uppercase text-zinc-950 focus:outline-hidden placeholder-zinc-300 rounded-none h-10"
                  disabled={status === "subbing"}
                />
              </div>

              <button
                id="newsletter-subscribe-btn"
                type="submit"
                disabled={status === "subbing"}
                className="w-full sm:w-auto bg-transparent text-zinc-950 hover:bg-zinc-950 hover:text-white border border-transparent hover:border-zinc-950 h-10 px-6 font-mono text-[11px] tracking-widest uppercase font-bold transition-all flex items-center justify-center space-x-2 shrink-0 rounded-none cursor-pointer"
              >
                {status === "subbing" ? (
                  <span>REGISTERING...</span>
                ) : (
                  <>
                    <span>JOIN</span>
                    <ArrowRight size={12} />
                  </>
                )}
              </button>
            </motion.form>
          ) : (
            <motion.div
              key="success-card"
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="max-w-md mx-auto bg-white border border-zinc-950 p-6 shadow-sm space-y-4 text-center rounded-none"
            >
              <div className="flex justify-center flex-col items-center space-y-1.5">
                <div className="w-8 h-8 rounded-full border border-zinc-950 flex items-center justify-center bg-zinc-50 text-zinc-955">
                  <Sparkles size={14} />
                </div>
                <h4 className="font-serif italic text-lg text-zinc-950 mt-1">Subscription Approved</h4>
                <p className="font-sans text-xs text-zinc-400 font-light leading-relaxed">
                  Thank you for subscribing. You are registered. You will receive priority updates, collection lookbook previews, and Kyiv and Rome atelier alerts directly to your inbox.
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {status === "error" && (
          <p className="text-[10px] font-mono uppercase text-amber-700 tracking-wider">
            ✕ Invalid email structure. Please check and retry.
          </p>
        )}
      </div>
    </section>
  );
}
