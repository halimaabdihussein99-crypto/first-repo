/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { ShoppingBag, Menu, X, ArrowRight } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface HeaderProps {
  currentView: "landing" | "shop" | "admin";
  setView: (view: "landing" | "shop" | "admin") => void;
  cartCount: number;
  onCartOpen: () => void;
  onNewsletterClick: () => void;
}

export default function Header({
  currentView,
  setView,
  cartCount,
  onCartOpen,
  onNewsletterClick,
}: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { label: "Lookbook", view: "landing" as const },
    { label: "Curated Shop", view: "shop" as const },
    { label: "Admin Panel", view: "admin" as const },
  ];

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-zinc-950">
      {/* Dynamic Announcement Line Bar */}
      <div className="bg-zinc-950 text-white py-2 px-4 text-center text-xs tracking-[0.18em] font-mono select-none border-b border-zinc-950">
        <span className="hidden sm:inline">FORMULATED BLACKPEARL LIMITED EDITIONS • ATELIER COLLECTION IN KYIV & ROME</span>
        <span className="sm:hidden">KYIV & ROME ATELIER COLLECTION ONLY</span>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-8 h-20 flex items-center justify-between">
        {/* Menu Trigger Mobile */}
        <button
          id="mobile-menu-trigger"
          className="p-2 -ml-2 text-zinc-900 md:hidden hover:opacity-70 transition-opacity"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          aria-label="Toggle Menu"
        >
          {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>

        {/* Brand Name / Logo */}
        <button
          id="brand-logo-trigger"
          onClick={() => {
            setView("landing");
            setMobileMenuOpen(false);
          }}
          className="flex flex-col items-center cursor-pointer group select-none text-left py-1"
        >
          {/* Custom High-Fidelity Blackpearl Monogram & Typography Logomark */}
          <svg
            viewBox="0 0 160 110"
            className="h-[52px] w-auto text-zinc-950 fill-current"
            xmlns="http://www.w3.org/2000/svg"
          >
            {/* Left Underline */}
            <rect x="40" y="72" width="33" height="4" />
            {/* Right Underline */}
            <rect x="87" y="72" width="33" height="4" />
            {/* Top Horizontal Bar */}
            <rect x="55" y="12" width="65" height="5" />
            {/* Left Vertical Stem of 'b' */}
            <rect x="40" y="12" width="5" height="50" />
            {/* Bottom Bowl Bar of 'b' */}
            <rect x="40" y="51" width="33" height="5" />
            {/* Top Bowl Bar of 'b' */}
            <rect x="40" y="29" width="33" height="5" />
            {/* Right Vertical Bar of 'b' bowl */}
            <rect x="68" y="29" width="5" height="27" />
            {/* Left Vertical Stem of 'p' */}
            <rect x="87" y="12" width="5" height="50" />
            {/* Right Vertical Bar of 'p' bowl */}
            <rect x="115" y="12" width="5" height="31" />
            {/* Bottom Bowl Bar of 'p' */}
            <rect x="87" y="38" width="33" height="5" />

            <text
              x="80"
              y="98"
              textAnchor="middle"
              className="font-sans font-normal tracking-[0.04em]"
              style={{ fontSize: "19px", fontFamily: '"Inter", sans-serif' }}
            >
              <tspan className="font-extrabold select-none">BLACK</tspan>
              <tspan className="select-none text-zinc-950" style={{ fontWeight: 200 }}>PEARL</tspan>
            </text>
          </svg>
        </button>

        {/* Navigation Desktop */}
        <nav className="hidden md:flex items-center space-x-12">
          {navItems.map((item) => (
            <button
              id={`nav-desktop-${item.view}`}
              key={item.label}
              onClick={() => setView(item.view)}
              className={`text-[11px] uppercase tracking-[0.2em] font-medium py-2 relative transition-all duration-300 hover:line-through ${
                currentView === item.view ? "text-zinc-950 font-semibold" : "text-zinc-400 hover:text-zinc-950"
              }`}
            >
              {item.label}
              {currentView === item.view && (
                <motion.div
                  layoutId="activeNavLine"
                  className="absolute bottom-0 left-0 right-0 h-[1.5px] bg-zinc-950"
                  transition={{ type: "spring", stiffness: 380, damping: 30 }}
                />
              )}
            </button>
          ))}
          <button
            id="nav-desktop-newsletter"
            onClick={onNewsletterClick}
            className="text-[11px] uppercase tracking-[0.2em] text-zinc-400 hover:text-zinc-950 font-medium py-2 transition-colors duration-300 hover:line-through"
          >
            Atelier Updates
          </button>
        </nav>

        {/* Action Elements */}
        <div className="flex items-center space-x-3 md:space-x-6">
          <button
            id="quick-shop-button"
            onClick={() => setView("shop")}
            className="hidden sm:flex items-center text-[10px] uppercase tracking-[0.2em] font-semibold border border-zinc-950 py-2.5 px-6 bg-zinc-950 text-white hover:bg-white hover:text-zinc-950 transition-all duration-300"
          >
            <span>Catalogue</span>
            <ArrowRight size={12} className="ml-2" />
          </button>

          {/* Cart trigger button */}
          <button
            id="cart-trigger-button"
            onClick={onCartOpen}
            className="relative p-2 flex items-center justify-center text-zinc-950 hover:bg-zinc-50 transition-all duration-200 border border-zinc-950 rounded-full px-4 py-1.5 text-[11px] uppercase tracking-[0.2em] font-medium"
            aria-label={`Open Bag with ${cartCount} items`}
          >
            <span className="mr-2">Bag</span>
            <span className="border border-zinc-950 bg-zinc-50 rounded-full px-2 py-0.5 text-[10px] font-semibold min-w-5">
              {cartCount < 10 ? `0${cartCount}` : cartCount}
            </span>
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.2 }}
            className="absolute left-0 right-0 bg-white border-b border-zinc-950 px-6 py-8 shadow-md z-[49] flex flex-col space-y-6 md:hidden"
          >
            {navItems.map((item) => (
              <button
                id={`nav-mobile-${item.view}`}
                key={item.label}
                onClick={() => {
                  setView(item.view);
                  setMobileMenuOpen(false);
                }}
                className={`text-left text-xs uppercase tracking-[0.2em] py-2 border-b ${
                  currentView === item.view ? "text-zinc-950 font-semibold pl-2 border-zinc-950" : "text-zinc-500 pl-0 border-zinc-200"
                } transition-all`}
              >
                {item.label}
              </button>
            ))}
            <button
              id="nav-mobile-newsletter"
              onClick={() => {
                onNewsletterClick();
                setMobileMenuOpen(false);
              }}
              className="text-left text-xs uppercase tracking-[0.2em] text-zinc-500 py-2 border-b border-zinc-200 hover:text-zinc-950"
            >
              Atelier Updates
            </button>
            <button
              id="nav-mobile-shop"
              onClick={() => {
                setView("shop");
                setMobileMenuOpen(false);
              }}
              className="w-full text-center bg-zinc-950 text-white font-mono uppercase text-xs tracking-widest py-4 border border-zinc-950 hover:bg-white hover:text-zinc-950 transition-all duration-300"
            >
              Shop All Collections
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
