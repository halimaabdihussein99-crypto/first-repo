/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import {
  X,
  CreditCard,
  Lock,
  ArrowLeft,
  ArrowRight,
  Printer,
  ShoppingBag,
  CheckCircle2,
  AlertCircle
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { CartItem, ShippingDetails, PaymentDetails, Order, formatPrice } from "../types";

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onOrderComplete: (order: Order) => void;
  onClearCart: () => void;
}

export default function CheckoutModal({
  isOpen,
  onClose,
  cartItems,
  onOrderComplete,
  onClearCart,
}: CheckoutModalProps) {
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingMsg, setProcessingMsg] = useState("");
  const [orderCreated, setOrderCreated] = useState<Order | null>(null);

  // Form Fields State
  const [shippingForm, setShippingForm] = useState<ShippingDetails>({
    fullName: "",
    email: "",
    address: "",
    apartment: "Atelier Collection Group",
    city: "Kyiv Atelier",
    postalCode: "Kyiv / Rome",
    country: "Ukraine / Italy",
    shippingMethod: "free",
    shippingCost: 0,
  });

  const [paymentForm, setPaymentForm] = useState<PaymentDetails>({
    cardName: "",
    cardNumber: "",
    expiryDate: "",
    cvv: "",
  });

  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  // Compute subtotal
  const subtotal = cartItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const isFreeShippingEligible = true;
  const deliveryCost = 0;

  if (!isOpen) return null;

  // Format Card Number (adds spaces every 4 digits)
  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\s+/g, "").replace(/[^0-9]/gi, "");
    let formattedValue = "";
    for (let i = 0; i < value.length; i++) {
      if (i > 0 && i % 4 === 0) {
        formattedValue += " ";
      }
      formattedValue += value[i];
    }
    setPaymentForm({ ...paymentForm, cardNumber: formattedValue.slice(0, 19) });
  };

  // Format Expiry MM/YY
  const handleExpiryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\s+/g, "").replace(/[^0-9]/gi, "");
    if (value.length > 2) {
      value = value.slice(0, 2) + "/" + value.slice(2, 4);
    }
    setPaymentForm({ ...paymentForm, expiryDate: value.slice(0, 5) });
  };

  const handleCvvChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/[^0-9]/gi, "");
    setPaymentForm({ ...paymentForm, cvv: value.slice(0, 4) });
  };

  // Validation step 1
  const validateShippingForm = () => {
    const errors: Record<string, string> = {};
    if (!shippingForm.fullName.trim()) errors.fullName = "Full name is required";
    if (!shippingForm.email.trim()) {
      errors.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(shippingForm.email)) {
      errors.email = "Invalid email formatting";
    }
    if (!shippingForm.address.trim()) errors.address = "Phone number is required";
    if (!shippingForm.city.trim()) errors.city = "Atelier showroom selection is required";

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // Validation step 2
  const validatePaymentForm = () => {
    const errors: Record<string, string> = {};
    if (!paymentForm.cardName.trim()) errors.cardName = "Cardholder name is required";
    if (paymentForm.cardNumber.replace(/\s/g, "").length < 15) {
      errors.cardNumber = "Valid 15 or 16-digit card number is required";
    }
    if (!/^(0[1-9]|1[0-2])\/\d{2}$/.test(paymentForm.expiryDate)) {
      errors.expiryDate = "Expiry date is required as MM/YY";
    }
    if (paymentForm.cvv.length < 3) errors.cvv = "Valid 3 or 4-digit security code is required";

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const proceedToPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateShippingForm()) {
      setStep(2);
      setFormErrors({});
    }
  };

  // Process order simulation
  const handleCheckoutSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validatePaymentForm()) return;

    setIsProcessing(true);
    setFormErrors({});

    // Visual phase loaders for premium secure atmosphere
    const loadingSteps = [
      "Establishing secure bank handshake...",
      "Encrypting primary account credentials...",
      "Authorizing worsted credit card token...",
      "Finalizing order configurations...",
    ];

    for (let i = 0; i < loadingSteps.length; i++) {
      setProcessingMsg(loadingSteps[i]);
      await new Promise((resolve) => setTimeout(resolve, 800));
    }

    // Compose custom Order Receipt
    const completedOrder: Order = {
      id: "BP-ORDER-" + Math.floor(100000 + Math.random() * 900000),
      items: [...cartItems],
      shipping: {
        ...shippingForm,
        shippingCost: deliveryCost,
        shippingMethod: isFreeShippingEligible ? "free" : "standard",
      },
      subtotal: subtotal,
      shippingCost: deliveryCost,
      discount: 0,
      total: subtotal + deliveryCost,
      date: new Date().toLocaleDateString("en-US", {
        year: "numeric",
        month: "long",
        day: "numeric",
      }),
      status: "processing",
    };

    setOrderCreated(completedOrder);
    onOrderComplete(completedOrder);
    onClearCart();
    setIsProcessing(false);
    setStep(3);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 overflow-hidden flex items-center justify-center p-4">
        {/* Backdrop overlay */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={step !== 3 ? onClose : undefined} // Avoid closing accidentally after success
          className="absolute inset-0 bg-zinc-950/50 backdrop-blur-xs cursor-pointer"
        />

        {/* Modal Window Cover */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          transition={{ duration: 0.4 }}
          className="relative bg-white w-full max-w-4xl h-[90vh] md:h-auto max-h-[850px] shadow-2xl flex flex-col md:grid md:grid-cols-12 overflow-hidden border border-zinc-950 z-10"
        >
          {/* Header Close button */}
          {step !== 3 && (
            <button
              id="close-checkout-modal-btn"
              onClick={onClose}
              className="absolute top-4 right-4 text-zinc-950 hover:text-black p-1 bg-white z-20 border border-zinc-950 transition-colors rounded-none"
              aria-label="Cancel Checkout"
            >
              <X size={16} />
            </button>
          )}

          {/* STEP 1: COLLECTION & INFORMATION */}
          {step === 1 && (
            <>
              {/* Collection Form Left */}
              <form
                id="shipping-form"
                onSubmit={proceedToPayment}
                className="col-span-7 p-6 md:p-10 flex flex-col justify-between overflow-y-auto max-h-full select-none"
              >
                <div className="space-y-6 text-left">
                  <div className="space-y-1.5 border-b border-zinc-950 pb-3">
                    <span className="font-mono text-[9px] tracking-[0.25em] text-zinc-400 uppercase">Secure Booking Form</span>
                    <h2 className="font-serif italic text-2xl md:text-3xl text-zinc-950 tracking-tight font-normal">Atelier Collection Details</h2>
                  </div>

                  {/* Form fields */}
                  <div className="space-y-4 font-mono text-[11px] uppercase tracking-wider text-zinc-500">
                    {/* Full Name */}
                    <div className="space-y-1">
                      <label htmlFor="fullName" className="font-bold text-zinc-800">Legal Full Name</label>
                      <input
                        id="fullName"
                        type="text"
                        placeholder="e.g., Rowan Vane"
                        value={shippingForm.fullName}
                        onChange={(e) => setShippingForm({ ...shippingForm, fullName: e.target.value })}
                        className={`w-full bg-zinc-50 hover:bg-zinc-100/50 focus:bg-white text-zinc-950 px-3.5 py-2.5 border placeholder-zinc-300 font-sans text-xs uppercase tracking-wide rounded-none focus:outline-hidden ${
                          formErrors.fullName ? "border-amber-600 focus:border-amber-600" : "border-zinc-200 focus:border-zinc-950"
                        } transition-colors`}
                      />
                      {formErrors.fullName && (
                        <p className="text-[10px] text-amber-700 font-bold flex items-center mt-1">
                          <AlertCircle size={10} className="mr-1 inline" /> {formErrors.fullName}
                        </p>
                      )}
                    </div>

                    {/* Email */}
                    <div className="space-y-1">
                      <label htmlFor="email" className="font-bold text-zinc-800">Email Address (Order Confirmation)</label>
                      <input
                        id="email"
                        type="email"
                        placeholder="e.g., ROWAN@BLACKPEARL.STUDIO"
                        value={shippingForm.email}
                        onChange={(e) => setShippingForm({ ...shippingForm, email: e.target.value })}
                        className={`w-full bg-zinc-50 hover:bg-zinc-100/50 focus:bg-white text-zinc-950 px-3.5 py-2.5 border placeholder-zinc-300 font-sans text-xs rounded-none focus:outline-hidden ${
                          formErrors.email ? "border-amber-600 focus:border-amber-600" : "border-zinc-200 focus:border-zinc-950"
                        } transition-colors`}
                      />
                      {formErrors.email && (
                        <p className="text-[10px] text-amber-700 font-bold flex items-center mt-1">
                          <AlertCircle size={10} className="mr-1 inline" /> {formErrors.email}
                        </p>
                      )}
                    </div>

                    {/* Phone Number mapping to shippingForm.address */}
                    <div className="space-y-1">
                      <label htmlFor="address" className="font-bold text-zinc-805">Contact Phone Number (For Pickup Alerts)</label>
                      <input
                        id="address"
                        type="text"
                        placeholder="e.g., +380-XX-XXX-XXXX / +39-XX-XXX-XXXX"
                        value={shippingForm.address}
                        onChange={(e) => setShippingForm({ ...shippingForm, address: e.target.value })}
                        className={`w-full bg-zinc-50 hover:bg-zinc-100/50 focus:bg-white text-zinc-950 px-3.5 py-2.5 border placeholder-zinc-300 font-sans text-xs uppercase tracking-wide rounded-none focus:outline-hidden ${
                          formErrors.address ? "border-amber-600 focus:border-amber-600" : "border-zinc-200 focus:border-zinc-950"
                        } transition-colors`}
                      />
                      {formErrors.address && (
                        <p className="text-[10px] text-amber-700 font-bold flex items-center mt-1">
                          <AlertCircle size={10} className="mr-1 inline" /> {formErrors.address}
                        </p>
                      )}
                    </div>

                    {/* Preferred Atelier Mapping to shippingForm.city */}
                    <div className="space-y-1">
                      <label htmlFor="city" className="font-bold text-zinc-800">Preferred Atelier Location</label>
                      <select
                        id="city"
                        value={shippingForm.city}
                        onChange={(e) => setShippingForm({ ...shippingForm, city: e.target.value })}
                        className="w-full bg-zinc-50 border border-zinc-200 hover:border-zinc-950 text-xs px-3 py-2.5 font-mono tracking-widest uppercase focus:outline-hidden text-zinc-900 focus:bg-white rounded-none cursor-pointer"
                      >
                        <option value="Kyiv Atelier">Kyiv Atelier Showroom (Ukraine)</option>
                        <option value="Rome Atelier">Rome Atelier Showroom (Italy)</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div className="pt-6 mt-6 border-t border-zinc-100 flex justify-end gap-3 font-mono">
                  <button
                    id="shipping-cancel-btn"
                    type="button"
                    onClick={onClose}
                    className="px-6 py-3 uppercase tracking-widest text-zinc-400 hover:text-zinc-950 text-[11px] font-semibold transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    id="shipping-submit-btn"
                    type="submit"
                    className="bg-zinc-950 text-white hover:bg-white hover:text-zinc-950 border border-zinc-950 px-6 py-3 uppercase tracking-widest text-[11px] font-semibold flex items-center space-x-2 transition-all group lg:px-8"
                  >
                    <span>Proceed to Verification</span>
                    <ArrowRight size={12} className="group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </form>
            </>
          )}

          {/* STEP 2: CREDIT CARD & PAYMENT */}
          {step === 2 && (
            <>
              {/* Secure Payment Form Left */}
              <form
                id="payment-form"
                onSubmit={handleCheckoutSubmit}
                className="col-span-7 p-6 md:p-10 flex flex-col justify-between overflow-y-auto max-h-full"
              >
                <div className="space-y-6 text-left select-none">
                  <div className="flex items-center space-x-2 border-b border-zinc-950 pb-3">
                    <button
                      id="payment-back-btn"
                      type="button"
                      onClick={() => setStep(1)}
                      className="p-1 px-2 text-zinc-950 hover:text-black mr-1 flex items-center bg-white border border-zinc-950 rounded-none"
                      title="Back to Shipping Details"
                    >
                      <ArrowLeft size={14} className="mr-1" />
                    </button>
                    <div>
                      <span className="font-mono text-[9px] tracking-[0.25em] text-zinc-400 uppercase">Step 02 of 02</span>
                      <h2 className="font-serif italic text-2xl md:text-3xl text-zinc-950 tracking-tight font-normal">Secure Checkout Shield</h2>
                    </div>
                  </div>

                  {/* HIGH-END INTERACTIVE MOCK CREDIT CARD INTERFACE */}
                  <div className="my-6">
                    <div className="aspect-[1.58/1] w-full max-w-sm mx-auto bg-zinc-950 rounded-lg p-5 text-white flex flex-col justify-between relative shadow-xl overflow-hidden font-mono border border-zinc-800">
                      {/* Abstract Pearl graphic watermark */}
                      <div className="absolute -bottom-8 -right-8 w-44 h-44 bg-neutral-900 border border-neutral-800/20 rounded-full pointer-events-none opacity-40 flex items-center justify-center">
                        <div className="w-24 h-24 bg-zinc-900 border border-zinc-800/40 rounded-full" />
                      </div>

                      {/* Card Type Header */}
                      <div className="flex justify-between items-start">
                        <span className="text-[10px] tracking-[0.2em] font-light text-zinc-400 italic uppercase">blackpearl studio</span>
                        <Lock size={14} className="text-zinc-500" />
                      </div>

                      {/* Mock Chip */}
                      <div className="w-10 h-7 bg-zinc-100 rounded-sm overflow-hidden flex flex-col justify-between p-1 opacity-70">
                        <div className="grid grid-cols-3 gap-0.5 h-full w-full">
                          <div className="border border-zinc-400" />
                          <div className="border border-zinc-400" />
                          <div className="border border-zinc-400" />
                        </div>
                      </div>

                      {/* Card Number display */}
                      <div className="text-base sm:text-lg tracking-[0.16em] text-zinc-200 mt-2 font-medium z-10 font-sans py-1">
                        {paymentForm.cardNumber || "•••• •••• •••• ••••"}
                      </div>

                      {/* Bottom Card Row info */}
                      <div className="flex justify-between items-end text-left z-10 text-[9px]">
                        <div className="space-y-[1px]">
                          <span className="text-[7px] text-zinc-500 uppercase tracking-widest font-bold">Holder Name</span>
                          <p className="tracking-widest font-semibold uppercase font-mono max-w-[170px] truncate text-zinc-300">
                            {paymentForm.cardName || "CARDHOLDER NAME"}
                          </p>
                        </div>
                        <div className="flex space-x-6">
                          <div className="space-y-[1px]">
                            <span className="text-[7px] text-zinc-500 uppercase tracking-widest font-bold">Expires</span>
                            <p className="font-semibold text-zinc-300">{paymentForm.expiryDate || "MM/YY"}</p>
                          </div>
                          <div className="space-y-[1px]">
                            <span className="text-[7px] text-zinc-500 uppercase tracking-widest font-bold">CVC</span>
                            <p className="font-semibold text-zinc-300">{paymentForm.cvv || "•••"}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Payment Inputs */}
                  <div className="space-y-4 font-mono text-[11px] uppercase tracking-wider text-zinc-500">
                    <div className="space-y-1">
                      <label htmlFor="cardName" className="font-bold text-zinc-800">Cardholder Name</label>
                      <input
                        id="cardName"
                        type="text"
                        placeholder="Name printed on card"
                        value={paymentForm.cardName}
                        onChange={(e) => setPaymentForm({ ...paymentForm, cardName: e.target.value })}
                        className={`w-full bg-zinc-50 hover:bg-zinc-100/50 focus:bg-white text-zinc-950 px-3.5 py-2.5 border placeholder-zinc-300 font-sans text-xs uppercase tracking-wide rounded-none focus:outline-hidden ${
                          formErrors.cardName ? "border-amber-600 focus:border-amber-600" : "border-zinc-200 focus:border-zinc-950"
                        } transition-colors`}
                      />
                      {formErrors.cardName && (
                        <p className="text-[10px] text-amber-700 font-bold mt-1">{formErrors.cardName}</p>
                      )}
                    </div>

                    <div className="space-y-1">
                      <label htmlFor="cardNumber" className="font-bold text-zinc-800">Primary Account Number (PAN)</label>
                      <input
                        id="cardNumber"
                        type="text"
                        placeholder="•••• •••• •••• ••••"
                        value={paymentForm.cardNumber}
                        onChange={handleCardNumberChange}
                        className={`w-full bg-zinc-50 hover:bg-zinc-100/50 focus:bg-white text-zinc-950 px-3.5 py-2.5 border placeholder-zinc-300 font-sans text-xs rounded-none focus:outline-hidden ${
                          formErrors.cardNumber ? "border-amber-600 focus:border-amber-600" : "border-zinc-200 focus:border-zinc-950"
                        } transition-colors`}
                      />
                      {formErrors.cardNumber && (
                        <p className="text-[10px] text-amber-700 font-bold mt-1">{formErrors.cardNumber}</p>
                      )}
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label htmlFor="expiryDate" className="font-bold text-zinc-800">Expiration (MM/YY)</label>
                        <input
                          id="expiryDate"
                          type="text"
                          placeholder="MM/YY"
                          value={paymentForm.expiryDate}
                          onChange={handleExpiryChange}
                          className={`w-full bg-zinc-50 hover:bg-zinc-100/50 focus:bg-white text-zinc-950 px-3.5 py-2.5 border placeholder-zinc-300 font-sans text-xs rounded-none focus:outline-hidden ${
                            formErrors.expiryDate ? "border-amber-600 focus:border-amber-600" : "border-zinc-200 focus:border-zinc-950"
                          } transition-colors`}
                        />
                        {formErrors.expiryDate && (
                          <p className="text-[10px] text-amber-700 font-bold mt-1">{formErrors.expiryDate}</p>
                        )}
                      </div>

                      <div className="space-y-1">
                        <label htmlFor="cvv" className="font-bold text-zinc-800">Card CVC / CVV</label>
                        <input
                          id="cvv"
                          type="password"
                          placeholder="CVC/CVV"
                          value={paymentForm.cvv}
                          onChange={handleCvvChange}
                          className={`w-full bg-zinc-50 hover:bg-zinc-100/50 focus:bg-white text-zinc-950 px-3.5 py-2.5 border placeholder-zinc-300 font-sans text-xs rounded-none focus:outline-hidden ${
                            formErrors.cvv ? "border-amber-600 focus:border-amber-600" : "border-zinc-200 focus:border-zinc-950"
                          } transition-colors`}
                        />
                        {formErrors.cvv && (
                          <p className="text-[10px] text-amber-700 font-bold mt-1">{formErrors.cvv}</p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="pt-6 mt-6 border-t border-zinc-100 flex justify-end gap-3 font-mono">
                  <button
                    id="payment-cancel-btn"
                    type="button"
                    onClick={() => setStep(1)}
                    disabled={isProcessing}
                    className="px-6 py-3 uppercase tracking-widest text-zinc-400 hover:text-zinc-950 text-[11px] font-semibold transition-colors disabled:opacity-50"
                  >
                    Stitch Back
                  </button>
                  <button
                    id="payment-submit-btn"
                    type="submit"
                    disabled={isProcessing}
                    className="bg-zinc-950 text-white hover:bg-white hover:text-zinc-950 border border-zinc-950 px-6 py-3 uppercase tracking-widest text-[11px] font-semibold flex items-center justify-center space-x-2 transition-all disabled:bg-zinc-800 disabled:text-zinc-400 disabled:pointer-events-none"
                  >
                    {isProcessing ? (
                      <span className="flex items-center space-x-2">
                        <svg className="animate-spin h-3.5 w-3.5 text-white inline shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        <span className="font-mono text-[9px] uppercase tracking-[0.25em] whitespace-nowrap">{processingMsg}</span>
                      </span>
                    ) : (
                      <>
                        <Lock size={11} />
                        <span>Authorize Subtotal • ${subtotal + deliveryCost}</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            </>
          )}

          {/* STEP 3: ORDER RECEIPT SUCCESS (Monochrome Printable Invoice) */}
          {step === 3 && orderCreated && (
            <div className="col-span-12 p-6 md:p-12 overflow-y-auto max-h-full flex flex-col items-center justify-center bg-zinc-50 border-t md:border-t-0 md:border-l border-zinc-950">
              <motion.div
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.6 }}
                className="w-full max-w-xl text-center space-y-6"
              >
                {/* Visual success logo indicator */}
                <div className="flex flex-col items-center space-y-3 select-none">
                  <div className="w-12 h-12 rounded-none border border-zinc-950 bg-white flex items-center justify-center text-zinc-950">
                    <CheckCircle2 size={32} strokeWidth={1} />
                  </div>
                  <span className="font-mono text-[10px] tracking-[0.3em] text-zinc-400 uppercase">Transaction Confirmed</span>
                  <h2 className="font-serif italic text-2xl md:text-4xl text-zinc-950 tracking-tight font-normal">Thank You Rowan</h2>
                  <p className="text-zinc-550 font-sans font-light text-xs sm:text-sm max-w-sm mt-1 leading-relaxed">
                    Order has been authorized and reserved. Premium gift wrapping, protective garment dust bags, and Atelier collection credentials will be prepared shortly.
                  </p>
                </div>

                {/* THE PRINTABLE MONOCHROME INVOICE RECEIPT TABLE */}
                <div className="bg-white border border-zinc-950 p-6 shadow-xs font-mono text-[11px] text-zinc-800 text-left relative overflow-hidden select-text rounded-none">
                  {/* Stylized edge pattern */}
                  <div className="absolute top-0 right-0 left-0 h-[2px] bg-zinc-950" />

                  {/* Receipt Header details */}
                  <div className="flex justify-between border-b border-zinc-950 pb-4 mb-4 uppercase text-zinc-400">
                    <div>
                      <span className="font-bold text-zinc-900">B L A C K P E A R L</span>
                      <p className="text-[9px] mt-0.5">SARTORIAL LABS INC.</p>
                    </div>
                    <div className="text-right">
                      <p>INVOICE NO: {orderCreated.id}</p>
                      <p className="text-[9px] mt-0.5">{orderCreated.date}</p>
                    </div>
                  </div>

                  {/* Collection summary */}
                  <div className="space-y-1 text-[10px] border-b border-zinc-100 pb-4 mb-4">
                    <span className="text-zinc-400 uppercase tracking-widest block font-bold text-[8px]">COLLECTION DETAILS:</span>
                    <p className="font-bold text-zinc-900 uppercase">{orderCreated.shipping.fullName}</p>
                    <p className="uppercase text-zinc-500">
                      PHONE: {orderCreated.shipping.address}
                    </p>
                    <p className="uppercase text-zinc-500">
                      LOCATION: {orderCreated.shipping.city}
                    </p>
                  </div>

                  {/* Purchased styles list */}
                  <div className="space-y-3 mb-6">
                    <span className="text-zinc-400 uppercase font-bold text-[8px] tracking-widest block">ORDER PACKING LIST:</span>
                    {orderCreated.items.map((item, idx) => (
                      <div key={idx} className="flex justify-between items-baseline text-zinc-900 uppercase">
                        <div>
                          <span>{item.product.name} ({item.selectedSize})</span>
                          <span className="text-zinc-400 font-normal ml-2">x{item.quantity}</span>
                        </div>
                        <span className="font-bold">{formatPrice(item.product.price * item.quantity)}</span>
                      </div>
                    ))}
                  </div>

                  {/* Totals spreadsheet calculations */}
                  <div className="border-t border-zinc-100 pt-4 space-y-1.5 font-mono">
                    <div className="flex justify-between text-zinc-400 uppercase">
                      <span>Gross subtotal</span>
                      <span>{formatPrice(orderCreated.subtotal)}</span>
                    </div>
                    <div className="flex justify-between text-zinc-400 uppercase">
                      <span>Showroom Collection fee</span>
                      <span>COMPLIMENTARY</span>
                    </div>
                    <div className="flex justify-between border-t border-dotted border-zinc-300 pt-3 text-zinc-950 font-bold text-xs uppercase">
                      <span>Total debited</span>
                      <span>{formatPrice(orderCreated.total)}</span>
                    </div>
                  </div>

                  {/* Signature message */}
                  <div className="mt-6 text-center border-t border-zinc-100 pt-4 text-zinc-400 text-[9px] uppercase tracking-wider">
                    Sartory guaranteed standard • certified original garments
                  </div>
                </div>

                {/* Print button / Close row */}
                <div className="flex flex-col sm:flex-row items-center justify-center gap-3 font-mono">
                  <button
                    id="print-invoice-btn"
                    onClick={() => window.print()}
                    className="w-full sm:w-auto bg-white hover:bg-zinc-50 text-zinc-950 border border-zinc-200 py-3.5 px-6 font-mono text-xs uppercase tracking-widest transition-all inline-flex items-center justify-center space-x-2"
                  >
                    <Printer size={13} />
                    <span>Print Invoice</span>
                  </button>

                  <button
                    id="finish-checkout-btn"
                    onClick={onClose}
                    className="w-full sm:w-auto bg-zinc-950 text-white hover:bg-white hover:text-zinc-950 border border-zinc-950 py-3.5 px-8 font-mono text-xs uppercase tracking-widest transition-all font-semibold"
                  >
                    Return to Catalog
                  </button>
                </div>
              </motion.div>
            </div>
          )}

          {/* RIGHT SIDEBAR: ORDER ITEMS SUMMARY (FOR STEPS 1 & 2) */}
          {step !== 3 && (
            <div className="col-span-5 bg-zinc-50 border-t md:border-t-0 md:border-l border-zinc-100 p-6 md:p-10 flex flex-col justify-between overflow-y-auto max-h-full font-sans select-none text-left">
              <div className="space-y-6">
                <span className="font-mono text-xs text-zinc-400 tracking-widest uppercase block">Order Invoice Details</span>

                {/* Item List */}
                <div className="space-y-4 max-h-[250px] overflow-y-auto pr-2">
                  {cartItems.map((item) => (
                    <div key={`${item.product.id}-${item.selectedSize}`} className="flex items-center space-x-3">
                      <div className="w-10 h-[13.33px] bg-zinc-100 border border-zinc-200/50 shrink-0">
                        <img
                          src={item.product.image}
                          alt={item.product.name}
                          className="w-full h-full object-cover grayscale"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                      <div className="flex-grow min-w-0">
                        <h4 className="text-zinc-900 text-xs font-medium truncate">{item.product.name}</h4>
                        <p className="font-mono text-[9px] text-zinc-400 uppercase mt-0.5">
                          Size: {item.selectedSize} • Qty: {item.quantity}
                        </p>
                      </div>
                      <span className="font-mono text-xs text-zinc-900 font-semibold shrink-0">
                        {formatPrice(item.product.price * item.quantity)}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Atelier Pickup notice */}
                <div className="bg-white border border-zinc-950/5 p-3 flex items-center space-x-2.5 shadow-sm text-[10px] font-mono uppercase tracking-widest text-zinc-800">
                  <CheckCircle2 size={14} className="text-zinc-950" />
                  <span>Kyiv & Rome Collection</span>
                </div>
              </div>

              {/* Summary Calculations */}
              <div className="space-y-3 font-mono text-[10px] border-t border-zinc-200/60 pt-6 mt-6">
                <div className="flex justify-between text-zinc-400 uppercase">
                  <span>Bag Items Subtotal</span>
                  <span>{formatPrice(subtotal)}</span>
                </div>
                <div className="flex justify-between text-zinc-400 uppercase">
                  <span>Showroom pickup</span>
                  <span className="text-emerald-700 font-bold">COMPLIMENTARY</span>
                </div>
                <div className="flex justify-between text-zinc-950 font-bold text-xs uppercase border-t border-zinc-205/65 pt-3">
                  <span>Total Debit</span>
                  <span>{formatPrice(subtotal)}</span>
                </div>

                <div className="pt-3 flex items-center space-x-1.5 text-zinc-400 text-[9px] font-sans justify-center">
                  <Lock size={10} className="text-zinc-500 shrink-0" />
                  <span className="uppercase tracking-widest font-mono">256-Bit SSL Encryption Activated</span>
                </div>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
