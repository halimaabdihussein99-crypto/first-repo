/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { CornerRightDown } from "lucide-react";

interface FooterProps {
  onNewsletterClick: () => void;
  onShopClick: () => void;
}

export default function Footer({ onNewsletterClick, onShopClick }: FooterProps) {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-white text-zinc-900 py-20 px-4 md:px-8 font-mono text-[10px] uppercase tracking-wider select-none border-t border-zinc-950">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-10 border-b border-zinc-950 pb-16 mb-12">
        
        {/* Brand identity column */}
        <div className="md:col-span-5 space-y-4 text-left">
          <div className="flex items-center">
            {/* Custom High-Fidelity Blackpearl Monogram & Typography Logomark */}
            <svg
              viewBox="0 0 160 110"
              className="h-[44px] w-auto text-zinc-950 fill-current"
              xmlns="http://www.w3.org/2000/svg"
            >
              {/* Left Underline */}
              <rect x="40" y="72" width="33" height="4" />
              {/* Right Underline */}
              <rect x="87" y="72" width="33" height="4" />
              {/* Top Horizontal Bar */}
              <rect x="55" y="12" width="65" height="5" />
              {/* Left Vertical Stem of 'b' */}
              <rect x="40" y="12" width="5" height="50" />
              {/* Bottom Bowl Bar of 'b' */}
              <rect x="40" y="51" width="33" height="5" />
              {/* Top Bowl Bar of 'b' */}
              <rect x="40" y="29" width="33" height="5" />
              {/* Right Vertical Bar of 'b' bowl */}
              <rect x="68" y="29" width="5" height="27" />
              {/* Left Vertical Stem of 'p' */}
              <rect x="87" y="12" width="5" height="50" />
              {/* Right Vertical Bar of 'p' bowl */}
              <rect x="115" y="12" width="5" height="31" />
              {/* Bottom Bowl Bar of 'p' */}
              <rect x="87" y="38" width="33" height="5" />

              <text
                x="80"
                y="98"
                textAnchor="middle"
                className="font-sans font-normal tracking-[0.04em]"
                style={{ fontSize: "19px", fontFamily: '"Inter", sans-serif' }}
              >
                <tspan className="font-extrabold select-none">BLACK</tspan>
                <tspan className="select-none text-zinc-950" style={{ fontWeight: 200 }}>PEARL</tspan>
              </text>
            </svg>
          </div>
          <p className="font-sans text-zinc-500 font-light lowercase tracking-normal text-xs normal-case leading-relaxed max-w-sm">
            Sartorial silence in absolute monochrome. An independent design laboratory formulating 12 definitive silhouettes a year. Tailoring responsibly milled in Rome and Tokyo.
          </p>
        </div>

        {/* Directory columns */}
        <div className="md:col-span-2 space-y-3 text-left">
          <span className="font-bold text-zinc-950 text-[11px] font-sans tracking-widest block border-b border-zinc-950 pb-2">Wardrobe</span>
          <ul className="space-y-2">
            <li>
              <button onClick={onShopClick} className="hover:line-through text-zinc-550 hover:text-zinc-950 transition-colors text-left py-0.5 cursor-pointer">
                All Collections
              </button>
            </li>
            <li>
              <button onClick={onShopClick} className="hover:line-through text-zinc-550 hover:text-zinc-950 transition-colors text-left py-0.5 cursor-pointer">
                Outerwear Shield
              </button>
            </li>
            <li>
              <button onClick={onShopClick} className="hover:line-through text-zinc-550 hover:text-zinc-950 transition-colors text-left py-0.5 cursor-pointer">
                Precision Tailoring
              </button>
            </li>
            <li>
              <button onClick={onShopClick} className="hover:line-through text-zinc-550 hover:text-zinc-950 transition-colors text-left py-0.5 cursor-pointer">
                Silk Slip Gowns
              </button>
            </li>
          </ul>
        </div>

        <div className="md:col-span-2 space-y-3 text-left">
          <span className="font-bold text-zinc-950 text-[11px] font-sans tracking-widest block border-b border-zinc-950 pb-2">Support</span>
          <ul className="space-y-2">
            <li>
              <span className="text-zinc-400 block py-0.5">Airway Tracking</span>
            </li>
            <li>
              <button onClick={onNewsletterClick} className="hover:line-through text-zinc-550 hover:text-zinc-950 transition-colors text-left py-0.5 cursor-pointer">
                Atelier Mailing List
              </button>
            </li>
            <li>
              <span className="text-zinc-400 block py-0.5">Care Formulations</span>
            </li>
            <li>
              <span className="text-zinc-400 block py-0.5">SSL Safe Payments</span>
            </li>
          </ul>
        </div>

        {/* Studio hours and contact column */}
        <div className="md:col-span-3 space-y-3 text-left">
          <span className="font-bold text-zinc-950 text-[11px] font-sans tracking-widest block border-b border-zinc-950 pb-2">Atelier Address</span>
          <p className="text-zinc-500 font-sans tracking-normal font-light normal-case text-xs">
            Blackpearl Kyoto Labs<br />
            14-2 Higashiyama Ward, Tokyo, JPN
          </p>
          <p className="text-zinc-500 font-sans tracking-normal font-light normal-case text-xs pt-1">
            Support: checkout@blackpearl.co.ke
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-zinc-400 text-[9px] uppercase tracking-widest font-mono">
        <div className="flex items-center space-x-1">
          <span>&copy; {currentYear} blackpearl apparel. all rights reserved.</span>
        </div>
        <div className="flex space-x-6">
          <span className="hover:text-zinc-950 cursor-help transition-colors hover:line-through">Privacy Charter</span>
          <span className="hover:text-zinc-950 cursor-help transition-colors hover:line-through">Terms of Silhouette</span>
          <span className="text-zinc-950 font-bold">SSL certified</span>
        </div>
      </div>
    </footer>
  );
}
