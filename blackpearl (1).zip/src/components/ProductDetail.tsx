/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { X, Star, MapPin, Heart, ArrowRight, CornerDownRight } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Product, formatPrice } from "../types";

interface ProductDetailProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, size: string, qty: number) => void;
}

export default function ProductDetail({ product, onClose, onAddToCart }: ProductDetailProps) {
  const [selectedSize, setSelectedSize] = useState("");
  const [qty, setQty] = useState(1);
  const [activeTab, setActiveTab] = useState<"desc" | "specs" | "shipping">("desc");
  const [addedMessage, setAddedMessage] = useState(false);
  const [sizeWarning, setSizeWarning] = useState(false);
  const [showSizeFormula, setShowSizeFormula] = useState(false);

  if (!product) return null;

  const isOutOfStock = product.stockCount !== undefined ? product.stockCount === 0 : (product.inStock === false);

  const handleAdd = () => {
    if (!selectedSize) {
      setSizeWarning(true);
      setTimeout(() => setSizeWarning(false), 3000);
      return;
    }
    onAddToCart(product, selectedSize, qty);
    setAddedMessage(true);
    setTimeout(() => {
      setAddedMessage(false);
    }, 2500);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 overflow-hidden flex items-center justify-end">
        {/* Backdrop glassmorphism overlay */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-neutral-950/45 cursor-pointer"
        />

        {/* Floating Sidebar Drawer */}
        <motion.div
          initial={{ x: "100%" }}
          animate={{ x: 0 }}
          exit={{ x: "100%" }}
          transition={{ type: "spring", damping: 33, stiffness: 240 }}
          className="relative w-full max-w-2xl h-full bg-white border-l border-zinc-990 flex flex-col overflow-hidden z-10"
        >
          {/* Header Bar */}
          <div className="absolute top-4 right-4 z-20">
            <button
              id="close-product-detail-btn"
              onClick={onClose}
              className="bg-white text-zinc-950 p-2.5 border border-zinc-950 hover:bg-zinc-950 hover:text-white transition-all cursor-pointer rounded-none"
              aria-label="Close details"
            >
              <X size={16} />
            </button>
          </div>

          {/* Drawer Body Wrap */}
          <div className="flex-grow overflow-y-auto">
            {/* 1. Dramatic Gallery View Cover */}
            <div className="relative aspect-[4/3] bg-neutral-100 border-b border-zinc-950">
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover object-center grayscale"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-zinc-950/50 via-transparent to-transparent pointer-events-none" />
              <div className="absolute bottom-6 left-6 text-white text-left select-none z-10">
                <span className="font-mono text-[9px] uppercase tracking-[0.25em] opacity-80">{product.category}</span>
                <h2 className="font-serif italic text-2xl sm:text-4xl tracking-tighter mt-1 font-normal">{product.name}</h2>
              </div>
            </div>

            {/* 2. Deep Specs Details Sheet */}
            <div className="p-6 md:p-8 space-y-8 select-none text-left">
              {/* Star and SKU meta row */}
              <div className="flex flex-wrap items-center justify-between gap-4 border-b border-zinc-950 pb-4">
                <div className="flex items-center space-x-2">
                  <div className="flex items-center space-x-1">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <Star
                        key={s}
                        size={12}
                        className={`${
                          s <= Math.floor(product.rating)
                            ? "fill-zinc-950 text-zinc-955"
                            : "text-zinc-200 fill-zinc-100"
                        }`}
                      />
                    ))}
                  </div>
                  <span className="font-mono text-[10px] text-zinc-805 uppercase pl-1">
                    {product.rating.toFixed(1)} / 5.0 Rating
                  </span>
                </div>

                <div className="flex items-center space-x-6 text-[10px] text-zinc-400 font-mono uppercase">
                  <span>SKU: {product.sku}</span>
                </div>
              </div>

              {/* Price details */}
              <div className="flex justify-between items-baseline">
                <span className="font-mono text-[10px] tracking-widest uppercase text-zinc-400">Price Structure</span>
                <div className="flex flex-col items-end">
                  <span className="font-mono text-2xl font-bold text-zinc-955">{formatPrice(product.price)}</span>
                  {product.stockCount !== undefined && (
                    <span className="font-mono text-[9px] uppercase tracking-wider text-zinc-400 mt-1">
                      {isOutOfStock ? "Out of Stock" : `${product.stockCount} styles remaining`}
                    </span>
                  )}
                </div>
              </div>

              {/* Dynamic Tabs Navigation */}
              <div className="border-b border-zinc-950 flex space-x-8">
                {[
                  { id: "desc" as const, label: "Philosophy" },
                  { id: "specs" as const, label: "Composition & Care" },
                  { id: "shipping" as const, label: "Atelier Pickup" },
                ].map((t) => (
                  <button
                    id={`detail-tab-${t.id}`}
                    key={t.id}
                    onClick={() => setActiveTab(t.id)}
                    className={`pb-3 text-[10px] uppercase tracking-[0.15em] font-semibold relative transition-colors cursor-pointer ${
                      activeTab === t.id ? "text-zinc-950" : "text-zinc-400 hover:text-zinc-950"
                    }`}
                  >
                    {t.label}
                    {activeTab === t.id && (
                      <motion.div
                        layoutId="activeTabUnderline"
                        className="absolute bottom-0 left-0 right-0 h-[1.5px] bg-zinc-950"
                      />
                    )}
                  </button>
                ))}
              </div>

              {/* Tabs Content */}
              <div className="min-h-[100px] text-zinc-600 font-sans font-light text-xs sm:text-sm leading-relaxed">
                {activeTab === "desc" && <p>{product.description}</p>}

                {activeTab === "specs" && (
                  <ul className="space-y-2.5 font-mono text-[10px] text-zinc-550 uppercase tracking-wide">
                    {product.details.map((detail, idx) => (
                      <li key={idx} className="flex items-start">
                        <CornerDownRight size={12} className="mr-2 mt-0.5 text-zinc-950 shrink-0" />
                        <span>{detail}</span>
                      </li>
                    ))}
                  </ul>
                )}

                {activeTab === "shipping" && (
                  <div className="space-y-3">
                    <p className="flex items-center space-x-2 font-medium text-zinc-950 border-b border-zinc-950 pb-2">
                      <MapPin size={14} />
                      <span className="uppercase text-[10px] tracking-wider font-bold">
                        Kyiv / Rome Showroom Collection
                      </span>
                    </p>
                    <p className="text-zinc-550 text-xs leading-relaxed">
                      This formulated garment is prepared exclusively for personal collection at our Kyiv (Ukraine) or Rome (Italy) Atelier showrooms. No courier delivery is provided. Once your reservation order is authorized, our custom sartorial team will contact you to schedule an exclusive showroom collection appointment.
                    </p>
                  </div>
                )}
              </div>

              {/* Size Selector Block */}
              <div className="space-y-4">
                <div className="flex justify-between text-[10px] font-mono tracking-widest uppercase">
                  <span className="text-zinc-950 font-bold">Select Sartorial Size</span>
                  <button
                    id="size-guide-toggle"
                    onClick={() => setShowSizeFormula(!showSizeFormula)}
                    className="text-zinc-400 hover:text-zinc-950 underline underline-offset-2 cursor-pointer"
                  >
                    {showSizeFormula ? "Hide Formula" : "Sizing Formula"}
                  </button>
                </div>

                <AnimatePresence>
                  {showSizeFormula && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      className="border border-zinc-950 p-4 bg-zinc-50 font-mono text-[9px] uppercase tracking-wider text-zinc-800 space-y-1 text-left"
                    >
                      <p className="font-bold border-b border-zinc-950 pb-1 mb-2">Blackpearl Sizing Matrix:</p>
                      <p>XS — CHEST: 32" | WAIST: 25" | HIPS: 35"</p>
                      <p>S  — CHEST: 34" | WAIST: 27" | HIPS: 37"</p>
                      <p>M  — CHEST: 36" | WAIST: 29" | HIPS: 39"</p>
                      <p>L  — CHEST: 39" | WAIST: 32" | HIPS: 42"</p>
                      <p>XL — CHEST: 42" | WAIST: 35" | HIPS: 45"</p>
                    </motion.div>
                  )}
                </AnimatePresence>

                <div className="flex flex-wrap gap-2.5">
                  {isOutOfStock ? (
                    <div className="w-full font-mono text-xs uppercase tracking-wider text-red-700 bg-red-50 p-3.5 border border-red-900 font-bold">
                      Sold Out — Sizing selection is temporarily restricted.
                    </div>
                  ) : (
                    product.sizes.map((size) => (
                      <button
                        id={`detail-size-${size}`}
                        key={size}
                        onClick={() => {
                          setSelectedSize(size);
                          setSizeWarning(false);
                        }}
                        className={`w-12 h-12 border text-xs tracking-wider font-mono uppercase font-semibold flex items-center justify-center transition-all cursor-pointer rounded-none ${
                          selectedSize === size
                            ? "bg-zinc-950 text-white border-zinc-950"
                            : "bg-white text-zinc-900 border-zinc-950 hover:bg-zinc-50"
                        }`}
                      >
                        {size}
                      </button>
                    ))
                  )}
                </div>
              </div>

              {/* Quantity Block */}
              <div className="space-y-3 border-t border-zinc-950 pt-6">
                <span className="font-mono text-[10px] text-zinc-400 uppercase tracking-widest block">Quantity Selection</span>
                <div className="flex items-center space-x-4">
                  <div className="flex items-center border border-zinc-950">
                    <button
                      id="qty-decrement-btn"
                      onClick={() => setQty(Math.max(1, qty - 1))}
                      className="px-4 py-1.5 hover:bg-zinc-50 font-mono transition-colors text-zinc-900 font-bold cursor-pointer"
                    >
                      -
                    </button>
                    <span className="px-5 py-1.5 font-mono text-xs font-bold text-zinc-950 border-x border-zinc-950 select-none">
                      {qty}
                    </span>
                    <button
                      id="qty-increment-btn"
                      onClick={() => setQty(qty + 1)}
                      className="px-4 py-1.5 hover:bg-zinc-50 font-mono transition-colors text-zinc-900 font-bold cursor-pointer"
                    >
                      +
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Action Trigger Sticky Button */}
          <div className="border-t border-zinc-950 p-6 bg-white flex flex-col space-y-3">
            <button
              id="add-to-bag-detail-cta"
              disabled={isOutOfStock}
              onClick={handleAdd}
              className={`w-full py-4 uppercase font-mono text-[11px] tracking-widest border font-bold transition-all rounded-none ${
                isOutOfStock
                  ? "bg-zinc-100 text-zinc-400 border-zinc-200 cursor-not-allowed"
                  : selectedSize
                  ? "bg-zinc-950 text-white border-zinc-950 hover:bg-white hover:text-zinc-950 cursor-pointer"
                  : "bg-zinc-100 text-zinc-400 border-zinc-200 cursor-not-allowed"
              }`}
            >
              {isOutOfStock 
                ? "Sold Out" 
                : selectedSize 
                ? `Add to luxury bag • ${formatPrice(product.price * qty)}` 
                : "Select Size above to add"}
            </button>

            <AnimatePresence>
              {sizeWarning && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="bg-amber-50 text-amber-900 text-[10px] font-mono uppercase tracking-wider py-2.5 px-3 text-center border border-amber-900"
                >
                  ⚠ SIZES REQUIRE SELECTION PRIOR TO ADDING ITEMS TO THE CARD BAG.
                </motion.div>
              )}

              {addedMessage && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="bg-neutral-50 text-zinc-950 text-[10px] py-2.5 px-3 border border-zinc-950 text-center font-mono tracking-wider uppercase"
                >
                  ✓ Style placed on our packing lists. Cart bag holds caskets securely.
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
