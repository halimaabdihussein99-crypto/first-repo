/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useMemo } from "react";
import { Filter, Search, RotateCcw, SlidersHorizontal, Check } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Product } from "../types";
import ProductCard from "./ProductCard";

interface GalleryProps {
  products: Product[];
  onProductClick: (product: Product) => void;
  onQuickAdd: (product: Product, size: string) => void;
  initialFilterFreeShipping?: boolean; // Can pre-filter free shipping if specified
}

type SortType = "curated" | "price-asc" | "price-desc" | "rating-desc";

export default function Gallery({ products, onProductClick, onQuickAdd, initialFilterFreeShipping = false }: GalleryProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [onlyFreeShipping, setOnlyFreeShipping] = useState(initialFilterFreeShipping);
  const [sortBy, setSortBy] = useState<SortType>("curated");
  const [isFiltersExpanded, setIsFiltersExpanded] = useState(false);

  const categories = [
    { id: "all", label: "All Items" },
    { id: "outerwear", label: "Outerwear" },
    { id: "tailoring", label: "Tailoring" },
    { id: "dresses", label: "Dresses" },
    { id: "essentials", label: "Essentials" },
    { id: "accessories", label: "Accessories" },
  ];

  // Advanced Reactive Filtering and Sorting Logic
  const filteredAndSortedProducts = useMemo(() => {
    let result = [...products];

    // 1. Search Query Search
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.sku.toLowerCase().includes(q)
      );
    }

    // 2. Category Selection
    if (selectedCategory !== "all") {
      result = result.filter((p) => p.category === selectedCategory);
    }

    // 3. Atelier Pickup Ready Filter
    if (onlyFreeShipping) {
      result = result.filter((p) => p.inStock !== false);
    }

    // 4. Sorting logic
    if (sortBy === "price-asc") {
      result.sort((a, b) => a.price - b.price);
    } else if (sortBy === "price-desc") {
      result.sort((a, b) => b.price - a.price);
    } else if (sortBy === "rating-desc") {
      result.sort((a, b) => b.rating - a.rating);
    }

    return result;
  }, [selectedCategory, searchQuery, onlyFreeShipping, sortBy]);

  const resetAllFilters = () => {
    setSelectedCategory("all");
    setSearchQuery("");
    setOnlyFreeShipping(false);
    setSortBy("curated");
  };

  const activeFiltersCount = useMemo(() => {
    let count = 0;
    if (selectedCategory !== "all") count++;
    if (searchQuery.trim() !== "") count++;
    if (onlyFreeShipping) count++;
    if (sortBy !== "curated") count++;
    return count;
  }, [selectedCategory, searchQuery, onlyFreeShipping, sortBy]);

  return (
    <section className="py-16 px-4 md:px-8 max-w-7xl mx-auto select-none text-left">
      {/* Upper Gallery Section Title */}
      <div className="border-b border-zinc-950 pb-8 mb-10 flex flex-col md:flex-row md:items-end md:justify-between gap-6">
        <div>
          <span className="font-mono text-[10px] text-zinc-400 uppercase tracking-[0.3em] block mb-2">Modern Wardrobe</span>
          <h2 className="font-serif italic text-3xl md:text-5xl text-zinc-950 tracking-tighter font-normal">Curated Catalogue</h2>
        </div>

        {/* Minimal Search and Slide Toggle Triggers */}
        <div className="flex flex-wrap items-center gap-3 animate-none">
          {/* Stark Search Input */}
          <div className="relative">
            <span className="absolute inset-y-0 left-3 flex items-center text-zinc-400">
              <Search size={13} />
            </span>
            <input
              id="gallery-search-input"
              type="text"
              placeholder="SEARCH PIECES..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-white hover:bg-zinc-50 focus:bg-white text-zinc-950 placeholder-zinc-300 border border-zinc-950 focus:border-zinc-950 focus:outline-hidden py-2.5 pl-9 pr-4 font-mono text-[10px] tracking-widest w-full sm:w-60 transition-all uppercase rounded-none"
            />
          </div>

          {/* Expand Filter Button */}
          <button
            id="expand-filters-trigger"
            onClick={() => setIsFiltersExpanded(!isFiltersExpanded)}
            className={`flex items-center space-x-2 py-2.5 px-5 font-mono text-xs uppercase tracking-widest border transition-all cursor-pointer ${
              isFiltersExpanded || activeFiltersCount > 0
                ? "bg-zinc-950 text-white border-zinc-950"
                : "bg-white text-zinc-805 border-zinc-950 hover:bg-zinc-50"
            }`}
          >
            <SlidersHorizontal size={12} />
            <span>Filters</span>
            {activeFiltersCount > 0 && (
              <span className="ml-1 bg-white text-zinc-950 font-mono text-[9px] w-4 h-4 rounded-full flex items-center justify-center font-bold">
                {activeFiltersCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Expandable Navigation Filtering System Panel */}
      <AnimatePresence>
        {isFiltersExpanded && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, duration: 0.3, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden border-b border-zinc-950 mb-10 pb-8"
          >
            <div className="grid grid-cols-1 md:grid-cols-12 gap-8 pt-2">
              {/* Category Filter Pills Column */}
              <div className="md:col-span-6 space-y-4">
                <span className="font-mono text-[10px] text-zinc-400 uppercase tracking-widest block">Categorical Curations</span>
                <div className="flex flex-wrap gap-2">
                  {categories.map((cat) => (
                    <button
                      id={`category-filter-${cat.id}`}
                      key={cat.id}
                      onClick={() => setSelectedCategory(cat.id)}
                      className={`text-[10px] uppercase font-mono tracking-widest px-4 py-2 border transition-all cursor-pointer ${
                        selectedCategory === cat.id
                          ? "bg-zinc-950 text-white border-zinc-950 font-semibold"
                          : "bg-white text-zinc-500 border-zinc-950 hover:bg-zinc-50"
                      }`}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Atelier Ready Focus Filter block */}
              <div className="md:col-span-3 space-y-4 text-left">
                <span className="font-mono text-[10px] text-zinc-400 uppercase tracking-widest block">Atelier Stock</span>
                <label className="flex items-center space-x-3 cursor-pointer select-none">
                  <div className="relative">
                    <input
                      id="free-shipping-filter-checkbox"
                      type="checkbox"
                      checked={onlyFreeShipping}
                      onChange={(e) => setOnlyFreeShipping(e.target.checked)}
                      className="sr-only"
                    />
                    <div className={`w-5 h-5 border flex items-center justify-center transition-all ${
                      onlyFreeShipping ? "bg-zinc-950 border-zinc-950 text-white" : "bg-white border-zinc-950 hover:bg-zinc-50"
                    }`}>
                      {onlyFreeShipping && <Check size={12} strokeWidth={3} />}
                    </div>
                  </div>
                  <div className="flex flex-col text-left">
                    <span className="text-[11px] uppercase tracking-widest font-bold text-zinc-950 leading-tight">Atelier Ready Only</span>
                    <span className="text-[9px] font-mono text-zinc-455 uppercase mt-0.5">Available for Pickup</span>
                  </div>
                </label>
              </div>

              {/* Sorting options Column */}
              <div className="md:col-span-3 space-y-4 text-left">
                <span className="font-mono text-[10px] text-zinc-400 uppercase tracking-widest block">Organize By</span>
                <div className="relative">
                  <select
                    id="gallery-sort-select"
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as SortType)}
                    className="w-full bg-white border border-zinc-950 hover:bg-zinc-50 text-[10px] px-3 py-2.5 font-mono tracking-widest uppercase focus:outline-hidden text-zinc-955 rounded-none cursor-pointer"
                  >
                    <option value="curated">Design Curated</option>
                    <option value="price-asc">Price: Low to High</option>
                    <option value="price-desc">Price: High to Low</option>
                    <option value="rating-desc">Highly Rated</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Clear Filters helper button */}
            {activeFiltersCount > 0 && (
              <div className="mt-8 flex justify-end border-t border-zinc-950 pt-4">
                <button
                  id="reset-filters-btn"
                  onClick={resetAllFilters}
                  className="flex items-center space-x-2 text-[10px] font-mono uppercase tracking-widest text-zinc-400 hover:text-zinc-950 transition-colors cursor-pointer"
                >
                  <RotateCcw size={10} />
                  <span>Stair Back to Defaults</span>
                </button>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Grid readout */}
      <div className="mb-6 flex justify-between items-baseline text-xs font-mono text-zinc-400 uppercase tracking-widest border-b border-zinc-950 pb-2">
        <span>Curated Catalog List</span>
        <span>
          Showing {filteredAndSortedProducts.length} of {products.length} designs
        </span>
      </div>

      {/* Bento-Inspired Modern Lookbook/Asymmetrical Grid Layout */}
      <AnimatePresence mode="popLayout">
        {filteredAndSortedProducts.length > 0 ? (
          <motion.div
            layout
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-12"
          >
            {filteredAndSortedProducts.map((prod) => (
              <ProductCard
                key={prod.id}
                product={prod}
                onClick={() => onProductClick(prod)}
                onQuickAdd={onQuickAdd}
              />
            ))}
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-24 bg-zinc-50 border border-zinc-100"
          >
            <div className="max-w-md mx-auto space-y-4">
              <span className="font-mono text-xs text-zinc-400 tracking-widest uppercase block">Result Void</span>
              <h3 className="font-display font-light text-xl text-zinc-900">No monochrome items align with your filter formulas.</h3>
              <p className="text-zinc-500 font-light text-xs leading-relaxed">
                Adjust or stair down search criteria to view blackpearl's primary catalog lines.
              </p>
              <button
                id="empty-gallery-reset-btn"
                onClick={resetAllFilters}
                className="bg-zinc-950 text-white hover:bg-white hover:text-zinc-950 border border-zinc-950 px-6 py-2.5 font-mono text-xs uppercase tracking-widest transition-all"
              >
                Restore Base Curation
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
