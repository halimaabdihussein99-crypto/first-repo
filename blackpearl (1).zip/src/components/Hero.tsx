/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ArrowRight, ShieldCheck, Heart, Eye } from "lucide-react";
import { motion } from "motion/react";
import { BRAND_ASSETS } from "../data";

interface HeroProps {
  onExploreClick: () => void;
}

export default function Hero({ onExploreClick }: HeroProps) {
  return (
    <div className="relative bg-white select-none">
      {/* 1. HERO HEADER HEADER STAGE (Magazine Style Cover) */}
      <section className="relative min-h-[calc(100vh-5rem)] flex flex-col justify-between overflow-hidden border-b border-zinc-950">
        {/* Decorative Grid Line Accents */}
        <div className="absolute inset-x-0 top-0 bottom-0 pointer-events-none flex justify-between max-w-7xl mx-auto px-4 md:px-8">
          <div className="w-[1px] bg-zinc-100 h-full hidden lg:block" />
          <div className="w-[1px] bg-zinc-100 h-full hidden lg:block" />
          <div className="w-[1px] bg-zinc-100 h-full hidden lg:block" />
        </div>

        {/* Upper Editorial Text */}
        <div className="max-w-7xl mx-auto w-full px-4 md:px-8 mt-12 md:mt-20 grid grid-cols-1 md:grid-cols-12 gap-6 z-10">
          <div className="md:col-span-8 text-left">
            <motion.h2
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.1 }}
              className="font-mono text-[10px] tracking-[0.3em] text-zinc-400 uppercase mb-4 opacity-80"
            >
              New Season / Autumn 26 / Issue No. 01
            </motion.h2>
            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.9, delay: 0.2 }}
              className="font-serif text-5xl sm:text-7xl lg:text-8xl tracking-tighter text-zinc-950 leading-[0.9] italic font-normal"
            >
              Pure Form,<br />
              <span className="not-italic font-normal font-serif text-zinc-900 tracking-tighter">Dark Matter.</span>
            </motion.h1>
          </div>
          <div className="md:col-span-4 flex flex-col justify-end md:pb-3 text-left">
            <motion.p
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.5 }}
              className="text-zinc-500 font-sans font-light text-xs sm:text-sm leading-relaxed max-w-sm"
            >
              A rigorous study in shadow, weave, and silhouette. Designed to shield the physical form, stripping away noise to honor structural essence.
            </motion.p>
          </div>
        </div>

        {/* Visual Showcase (Big Hero Block) */}
        <div className="max-w-7xl mx-auto w-full px-4 md:px-8 my-10 md:my-14 z-10 flex-grow flex items-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
            className="relative w-full aspect-[21/9] sm:aspect-[16/6] bg-zinc-50 overflow-hidden group border border-zinc-950"
          >
            {/* The dramatic B&W Hero Image */}
            <img
              src={BRAND_ASSETS.hero}
              alt="blackpearl high fashion black and white editorial photoshoot"
              className="w-full h-full object-cover object-center grayscale hover:scale-105 transition-transform duration-[2.5s] ease-[0.16, 1, 0.3, 1]"
              referrerPolicy="no-referrer"
            />
            {/* Elegant overlay card vignette */}
            <div className="absolute inset-0 bg-gradient-to-t from-zinc-950/45 via-transparent to-zinc-950/10 pointer-events-none" />
            
            {/* Embedded look overlay card tag */}
            <div className="absolute bottom-4 left-4 md:bottom-8 md:left-8 text-white select-none text-left">
              <span className="font-mono text-[9px] tracking-[0.3em] uppercase opacity-80">Featured Look / Autumn 26</span>
              <h3 className="font-serif italic text-xl md:text-3xl tracking-tight mt-1">The Silk Overcoat</h3>
            </div>
            
            <div className="absolute bottom-4 right-4 md:bottom-8 md:right-8">
              <button
                id="hero-cta-button"
                onClick={onExploreClick}
                className="bg-white text-zinc-950 px-8 py-3.5 border border-zinc-950 uppercase text-[10px] tracking-widest font-semibold hover:bg-black hover:text-white transition-colors"
                aria-label="Shop the Look"
              >
                View Collection
              </button>
            </div>
          </motion.div>
        </div>

        {/* Banner metadata bottom details */}
        <div className="border-t border-zinc-950 py-8 max-w-7xl mx-auto w-full px-4 md:px-8 grid grid-cols-2 md:grid-cols-4 gap-6 text-[10px] tracking-widest font-mono text-zinc-400 z-10 uppercase text-left">
          <div>
            <span className="text-zinc-400/80">Concept</span>
            <p className="text-zinc-950 font-bold mt-1">Stark Absolute</p>
          </div>
          <div>
            <span className="text-zinc-400/80">Materials</span>
            <p className="text-zinc-950 font-bold mt-1">Cashmere & Mulberry Silk</p>
          </div>
          <div>
            <span className="text-zinc-400/80">Origin</span>
            <p className="text-zinc-950 font-bold mt-1">Sartorial Kyoto & Rome</p>
          </div>
          <div className="text-right flex items-center justify-end">
            <button
              id="hero-discover-collections"
              onClick={onExploreClick}
              className="text-zinc-950 font-bold hover:line-through transition-all underline decoration-zinc-400 underline-offset-4 cursor-pointer"
            >
              Enter The Gallery
            </button>
          </div>
        </div>
      </section>

      {/* 2. PHILOSOPHY & STORY SECTION */}
      <section className="bg-neutral-50 border-y border-zinc-950 py-24 md:py-32 selection:bg-black selection:text-white">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <span className="font-mono text-[10px] text-zinc-400 uppercase tracking-[0.3em]">Our Manifesto</span>
            <h2 className="font-serif italic text-3xl md:text-5xl text-zinc-950 tracking-tight mt-6 mb-8 leading-relaxed font-normal">
              &ldquo;Color is a distraction. Black is the defining boundary of form; White is the truth of light. Blackpearl lives in their interface.&rdquo;
            </h2>
            <div className="h-[1px] w-20 bg-zinc-950 mx-auto mb-8" />
            <p className="text-zinc-650 font-sans font-light max-w-2xl mx-auto leading-relaxed text-sm">
              We design structured minimalist uniforms for the modern citizen. Rejecting fast-fashion volume cycles, we formulate 12 definitive items a year. Structured from sustainable mulberry silken twills and Italian virgin worsted fiber weaves.
            </p>
          </motion.div>
        </div>
      </section>

      {/* 3. THREE-COLUMN LOOKBOOK COLLAGE */}
      <section className="py-24 max-w-7xl mx-auto px-4 md:px-8 border-b border-zinc-950">
        <div className="mb-16 flex flex-col md:flex-row md:items-end md:justify-between text-left">
          <div>
            <span className="font-mono text-[10px] text-zinc-400 tracking-widest uppercase mb-2 block">The Visual Study</span>
            <h3 className="font-serif italic text-3xl md:text-5xl text-zinc-950 tracking-tighter">Lookbook Scenarios</h3>
          </div>
          <button
            id="collage-explore-cta"
            onClick={onExploreClick}
            className="text-[11px] uppercase tracking-[0.2em] font-medium text-zinc-950 hover:line-through mt-4 md:mt-0 flex items-center space-x-2"
          >
            <span>View All Pieces</span>
            <ArrowRight size={14} />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Collage Item 1 - Suit */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="group cursor-pointer text-left"
            onClick={onExploreClick}
          >
            <div className="aspect-[3/4] bg-neutral-100 overflow-hidden relative border border-zinc-955">
              <img
                src={BRAND_ASSETS.suit}
                alt="Sartorial Suit"
                className="w-full h-full object-cover grayscale group-hover:scale-105 transition-transform duration-[1.5s]"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-black/10 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <span className="bg-white border border-zinc-950 text-zinc-950 font-mono text-[10px] tracking-widest uppercase py-2 px-5 shadow-sm">Shop Suit Collection</span>
              </div>
            </div>
            <div className="mt-4 flex justify-between items-baseline font-sans">
              <h4 className="text-zinc-900 font-medium tracking-wide text-xs uppercase">Design 01: Pure Tailoring</h4>
              <span className="text-zinc-400 font-serif italic text-xs">Wool & Cashmere</span>
            </div>
          </motion.div>

          {/* Collage Item 2 - Dress */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="group cursor-pointer md:-translate-y-6 text-left"
            onClick={onExploreClick}
          >
            <div className="aspect-[3/4] bg-neutral-100 overflow-hidden relative border border-zinc-955">
              <img
                src={BRAND_ASSETS.dress}
                alt="Mulberry Silk Dress"
                className="w-full h-full object-cover grayscale group-hover:scale-105 transition-transform duration-[1.5s]"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-black/10 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <span className="bg-white border border-zinc-950 text-zinc-950 font-mono text-[10px] tracking-widest uppercase py-2 px-5 shadow-sm">Shop Silk Dress</span>
              </div>
            </div>
            <div className="mt-4 flex justify-between items-baseline font-sans">
              <h4 className="text-zinc-900 font-medium tracking-wide text-xs uppercase">Design 02: Fluid Gowns</h4>
              <span className="text-zinc-400 font-serif italic text-xs">Recycled Silk</span>
            </div>
          </motion.div>

          {/* Collage Item 3 - Trench */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="group cursor-pointer text-left"
            onClick={onExploreClick}
          >
            <div className="aspect-[3/4] bg-neutral-100 overflow-hidden relative border border-zinc-955">
              <img
                src={BRAND_ASSETS.trench}
                alt="Sartorial Overcoat"
                className="w-full h-full object-cover grayscale group-hover:scale-105 transition-transform duration-[1.5s]"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-black/10 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <span className="bg-white border border-zinc-950 text-zinc-950 font-mono text-[10px] tracking-widest uppercase py-2 px-5 shadow-sm font-medium">Shop Outerwear</span>
              </div>
            </div>
            <div className="mt-4 flex justify-between items-baseline font-sans">
              <h4 className="text-zinc-900 font-medium tracking-wide text-xs uppercase">Design 03: Cashmere Shields</h4>
              <span className="text-zinc-400 font-serif italic text-xs">Italian Twills</span>
            </div>
          </motion.div>
        </div>
      </section>

      {/* 4. VALUE PROPOSITIONS */}
      <section className="bg-white text-zinc-950 py-20 px-6 max-w-7xl mx-auto border-b border-zinc-955">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 text-left">
          <div className="space-y-3">
            <h4 className="font-serif italic text-xl text-zinc-950">Complimentary Global Delivery</h4>
            <p className="text-zinc-550 text-xs sm:text-sm font-light leading-relaxed font-sans">
              Every curated piece is delivered in custom-commissioned dust protection sleeves via express logistics, with free delivery filtering natively on our catalog.
            </p>
          </div>
          <div className="space-y-3 md:border-l border-zinc-950 md:pl-10">
            <h4 className="font-serif italic text-xl text-zinc-950">Monochrome Assurance</h4>
            <p className="text-zinc-550 text-xs sm:text-sm font-light leading-relaxed font-sans">
              We exclusively utilize deep mineral dyes and carbon treatment blocks. No secondary colors exist in our facilities, maintaining sartorial monochrome purity.
            </p>
          </div>
          <div className="space-y-3 md:border-l border-zinc-950 md:pl-10">
            <h4 className="font-serif italic text-xl text-zinc-950">Guaranteed Secure Checkout</h4>
            <p className="text-zinc-550 text-xs sm:text-sm font-light leading-relaxed font-sans">
              All interactions are protected with 256-bit bank-grade SSL layers. Credit details are safely processed to authorize transactions securely on checkout.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
