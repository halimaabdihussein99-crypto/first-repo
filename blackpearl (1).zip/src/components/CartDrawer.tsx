/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { X, Trash2, ShieldCheck, ArrowRight } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { CartItem, Product, formatPrice } from "../types";

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQty: (product: Product, size: string, delta: number) => void;
  onRemoveItem: (product: Product, size: string) => void;
  onCheckoutOpen: () => void;
  onViewProductsClick: () => void;
}

export default function CartDrawer({
  isOpen,
  onClose,
  cartItems,
  onUpdateQty,
  onRemoveItem,
  onCheckoutOpen,
  onViewProductsClick,
}: CartDrawerProps) {
  // Compute Subtotal
  const subtotal = cartItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 overflow-hidden flex items-center justify-end">
        {/* Backdrop glassmorphism overlay */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-zinc-950/40 backdrop-blur-xs cursor-pointer"
        />

        {/* Floating Sidebar Drawer */}
        <motion.div
          initial={{ x: "100%" }}
          animate={{ x: 0 }}
          exit={{ x: "100%" }}
          transition={{ type: "spring", damping: 33, stiffness: 240 }}
          className="relative w-full max-w-md h-full bg-white border-l border-zinc-950 flex flex-col z-10"
        >
          {/* Header */}
          <div className="p-6 border-b border-zinc-950 flex items-center justify-between select-none">
            <div className="text-left">
              <h2 className="font-serif italic text-2xl text-zinc-950 tracking-tight font-normal">Your Shopping Bag</h2>
              <span className="font-mono text-[9px] text-zinc-400 uppercase tracking-widest block mt-0.5">
                {cartItems.length} styles added
              </span>
            </div>
            <button
              id="close-cart-btn"
              onClick={onClose}
              className="p-2 border border-zinc-950 text-zinc-950 bg-white hover:bg-zinc-950 hover:text-white transition-all rounded-none cursor-pointer"
              aria-label="Close bag"
            >
              <X size={15} />
            </button>
          </div>

          {/* Atelier Pickup Notice */}
          <div className="px-6 py-4 bg-zinc-50 border-b border-zinc-950 text-left select-none">
            <div className="space-y-1.5">
              <p className="flex items-center space-x-2 text-zinc-950 font-bold text-xs uppercase tracking-wider">
                <ShieldCheck size={14} className="text-zinc-950 shrink-0" />
                <span>Atelier Pickup Only</span>
              </p>
              <p className="text-[10px] text-zinc-500 font-mono uppercase leading-relaxed">
                Notice: We do not ship or mail garments. Purchases are formulated in limited editions and prepared exclusively for personal collection at our Kyiv or Rome Atelier showrooms.
              </p>
            </div>
          </div>

          {/* Cart Items List */}
          <div className="flex-grow overflow-y-auto p-6 space-y-6">
            {cartItems.length > 0 ? (
              cartItems.map((item) => (
                <div
                  key={`${item.product.id}-${item.selectedSize}`}
                  className="flex items-start space-x-4 border-b border-zinc-950 pb-6 last:border-0 last:pb-0 text-left"
                >
                  {/* Thumbnail frame */}
                  <div className="w-16 h-[21.33px] aspect-[3/4] bg-neutral-100 border border-zinc-950 shrink-0 select-none">
                    <img
                      src={item.product.image}
                      alt={item.product.name}
                      className="w-full h-full object-cover grayscale"
                      referrerPolicy="no-referrer"
                    />
                  </div>

                  {/* Descriptions block */}
                  <div className="flex-grow space-y-1">
                    <div className="flex justify-between items-start">
                      <h3 className="font-serif italic text-zinc-950 text-sm tracking-tight leading-snug">
                        {item.product.name}
                      </h3>
                      <button
                        id={`remove-cart-item-${item.product.id}-${item.selectedSize}`}
                        onClick={() => onRemoveItem(item.product, item.selectedSize)}
                        className="text-zinc-400 hover:text-zinc-950 p-1 rounded-none transition-colors cursor-pointer"
                        title="Remove style specification"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>

                    <p className="font-mono text-[9px] text-zinc-400 uppercase tracking-widest pl-0.5">
                      Size: <strong className="text-zinc-850 font-bold">{item.selectedSize}</strong>
                    </p>

                    {/* Qty and price row */}
                    <div className="flex justify-between items-center pt-2 select-none">
                      {/* Qty incrementer */}
                      <div className="flex items-center border border-zinc-950">
                        <button
                          id={`qty-dec-${item.product.id}-${item.selectedSize}`}
                          onClick={() => onUpdateQty(item.product, item.selectedSize, -1)}
                          className="px-2.5 py-1 text-zinc-500 hover:text-zinc-900 font-mono transition-colors text-xs font-bold cursor-pointer"
                        >
                          -
                        </button>
                        <span className="px-3 py-1 font-mono text-[10px] font-bold text-zinc-950 border-x border-zinc-950 select-none">
                          {item.quantity}
                        </span>
                        <button
                          id={`qty-inc-${item.product.id}-${item.selectedSize}`}
                          onClick={() => onUpdateQty(item.product, item.selectedSize, 1)}
                          className="px-2.5 py-1 text-zinc-500 hover:text-zinc-900 font-mono transition-colors text-xs font-bold cursor-pointer"
                        >
                          +
                        </button>
                      </div>

                      <span className="font-mono text-xs font-bold text-zinc-950">
                        {formatPrice(item.product.price * item.quantity)}
                      </span>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="h-full flex flex-col items-center justify-center py-16 text-center select-none space-y-4">
                <span className="font-mono text-[9px] tracking-[0.25em] text-zinc-400 uppercase">Bag is Empty</span>
                <p className="font-serif italic text-zinc-900 text-lg max-w-xs leading-relaxed font-normal">
                  Your luxury bag lies silent. We invite you to explore blackpearl’s lookbook lines.
                </p>
                <button
                  id="empty-cart-discover-btn"
                  onClick={() => {
                    onViewProductsClick();
                    onClose();
                  }}
                  className="bg-zinc-950 text-white hover:bg-white hover:text-zinc-950 border border-zinc-950 px-6 py-2.5 font-mono text-xs uppercase tracking-widest transition-all cursor-pointer rounded-none"
                >
                  Explore Garments
                </button>
              </div>
            )}
          </div>

          {/* Persistent checkout calculations panel */}
          {cartItems.length > 0 && (
            <div className="border-t border-zinc-950 p-6 bg-white space-y-5 select-none">
              <div className="space-y-2 text-xs font-mono tracking-widest uppercase">
                <div className="flex justify-between text-zinc-400">
                  <span>Bag Subtotal</span>
                  <span className="font-bold text-zinc-950">{formatPrice(subtotal)}</span>
                </div>
                <div className="flex justify-between border-t border-zinc-950 pt-3 text-sm text-zinc-950">
                  <span className="font-bold">Total Collection Price</span>
                  <span className="font-bold">{formatPrice(subtotal)}</span>
                </div>
              </div>

              {/* Secure transaction certificate line */}
              <div className="flex items-center justify-center space-x-1.5 text-zinc-400 text-[10px] font-sans">
                <ShieldCheck size={11} className="text-zinc-600 shrink-0" />
                <span className="uppercase tracking-widest font-mono">Secure SSL Transactions Enabled</span>
              </div>

              {/* Checkout CTA */}
              <button
                id="cart-checkout-trigger"
                onClick={onCheckoutOpen}
                className="w-full bg-zinc-950 text-white hover:bg-white hover:text-zinc-950 border border-zinc-950 py-4 uppercase font-mono text-xs tracking-widest font-semibold flex items-center justify-center space-x-2 transition-all cursor-pointer group rounded-none"
              >
                <span>Proceed to Checkout</span>
                <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
