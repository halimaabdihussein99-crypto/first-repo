/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Product {
  id: string;
  name: string;
  price: number;
  category: "outerwear" | "tailoring" | "dresses" | "essentials" | "accessories";
  description: string;
  image: string; // URL path of the high-end image
  details: string[]; // List of fabric details or unique features
  sizes: string[]; // Available sizing, e.g., ["XS", "S", "M", "L", "XL"]
  hasFreeShipping: boolean; // Vital for the free shipping filter option
  rating: number; // Star rating or 5-point rating
  sku: string; // Product SKU
  stockCount?: number; // Numeric value of items in stock
  inStock?: boolean; // Expresses stock availability explicitly
}

export interface CartItem {
  product: Product;
  selectedSize: string;
  quantity: number;
}

export interface ShippingDetails {
  fullName: string;
  email: string;
  address: string;
  apartment?: string;
  city: string;
  postalCode: string;
  country: string;
  shippingMethod: "standard" | "express" | "free";
  shippingCost: number;
}

export interface PaymentDetails {
  cardName: string;
  cardNumber: string;
  expiryDate: string;
  cvv: string;
}

export interface Order {
  id: string;
  items: CartItem[];
  shipping: ShippingDetails;
  subtotal: number;
  shippingCost: number;
  discount: number;
  total: number;
  date: string;
  status: "processing" | "shipped" | "delivered";
}

export function formatPrice(price: number): string {
  return `KSh ${price.toLocaleString()}`;
}
